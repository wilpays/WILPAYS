import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Login from './pages/Login';
import Signup from './pages/Signup';
import HomePage from './pages/HomePage';
import ConfirmarCodigo from './pages/ConfirmarCodigo';
import EmailConfirmado from './pages/EmailConfirmado';
import MarketplacePage from './pages/Marketplace';
import ProfilePage from './pages/ProfilePage';
import ProfilePageCliente from './pages/ProfilePageCliente';
import ProductDetailPage from './pages/ProductDetailPage';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/login" element={<Login />} />
        <Route path="/signup" element={<Signup />} />
        <Route path="/confirmar-codigo" element={<ConfirmarCodigo />} />
        <Route path="/sucesso" element={<EmailConfirmado />} />
        <Route path="/marketplace" element={<MarketplacePage />} />
        <Route path="/perfil" element={<ProfilePage />} />
        <Route path="/product/:id" element={<ProductDetailPage />} />
        <Route path="/client" element={<ProfilePageCliente /> } />
      </Routes>
    </Router>
  );
}

export default App;
