import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App'
import { library } from '@fortawesome/fontawesome-svg-core';
import { faBars, faLeaf, faSeedling, faTractor, faUsers, faStar, faChevronRight, faArrowRight } from '@fortawesome/free-solid-svg-icons';
import { faFacebook, faTwitter, faInstagram, faLinkedin } from '@fortawesome/free-brands-svg-icons';

// Adicione os ícones que você usará à biblioteca
library.add(faBars, faLeaf, faSeedling, faTractor, faUsers, faStar, faChevronRight, faArrowRight, faFacebook, faTwitter, faInstagram, faLinkedin);



createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
)
