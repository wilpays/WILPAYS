import { useNavigate } from "react-router-dom";
import { useEffect } from "react";

const Sucesso = () => {
  const navigate = useNavigate();

  useEffect(() => {
    localStorage.removeItem("signupData");
    localStorage.removeItem("codigoVerificacao");
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center px-4 py-12">
      <div className="max-w-md w-full bg-white shadow-xl rounded-2xl p-8 text-center">
        <div className="mb-6">
          <svg
            className="mx-auto h-16 w-16 text-green-500"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
          </svg>
        </div>

        <h2 className="text-2xl font-semibold text-gray-800 mb-2">Cadastro concluído com sucesso!</h2>
        <p className="text-sm text-gray-600 mb-6">
          Sua conta foi criada com sucesso. Agora você pode iniciar sessão ou explorar o painel.
        </p>

        <div className="space-y-3">

          <button
            onClick={() => navigate("/login")}
            className="w-full py-2 bg-gray-100 text-gray-700 font-medium rounded-md hover:bg-gray-200 transition"
          >
            Iniciar sessão
          </button>

          <button
            onClick={() => navigate("/")}
            className="w-full py-2 text-sm text-gray-500 hover:text-blue-600 transition"
          >
            Voltar à página inicial
          </button>
        </div>
      </div>
    </div>
  );
};

export default Sucesso;
