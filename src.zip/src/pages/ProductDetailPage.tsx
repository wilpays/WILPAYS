import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc } from 'firebase/firestore';
import { db } from '../firebase/firebaseConfig';
import { motion } from 'framer-motion';
import { HiOutlineShoppingCart, HiOutlineArrowLeft } from 'react-icons/hi';
import { FaCheckCircle } from 'react-icons/fa';

// Definição da interface para os dados do produto
interface Product {
    id: string;
    name: string;
    price: string;
    author: string;
    image: string;
    category: string;
    description: string;
    gallery: string[];
    status: string; // <-- Adicionada a propriedade 'status'
}

const ProductDetailPage: React.FC = () => {
    const { id } = useParams<{ id: string }>();
    const navigate = useNavigate();
    const [product, setProduct] = useState<Product | null>(null);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const fetchProduct = async () => {
            if (!id) {
                setError("ID do produto não fornecido.");
                setLoading(false);
                return;
            }

            setLoading(true);
            try {
                const docRef = doc(db, 'products', id);
                const docSnap = await getDoc(docRef);

                if (docSnap.exists()) {
                    const data = docSnap.data();

                    // Verifica o status do produto
                    if (data.status !== 'Ativo') {
                        setError("Este produto está indisponível para compra no momento.");
                        setLoading(false);
                        return; // Interrompe a função se o produto não estiver ativo
                    }

                    setProduct({
                        id: docSnap.id,
                        name: data.productName,
                        price: `MT ${data.price.toLocaleString('pt-MZ')}`,
                        author: data.authorId,
                        image: data.coverImageUrl,
                        category: data.productType === 'livro' ? 'E-books' : 'Cursos',
                        description: data.description,
                        gallery: [data.coverImageUrl, ...data.fileUrls.filter((url: string) => url.endsWith('.jpg') || url.endsWith('.png') || url.endsWith('.jpeg'))],
                        status: data.status, // <-- Atribui o status ao estado do componente
                    });
                } else {
                    setError("Produto não encontrado.");
                }
            } catch (err) {
                console.error("Erro ao buscar produto:", err);
                setError("Falha ao carregar os detalhes do produto.");
            } finally {
                setLoading(false);
            }
        };

        fetchProduct();
    }, [id]);

    if (loading) {
        return (
            <div className="flex items-center justify-center min-h-screen text-xl text-gray-700">
                Carregando detalhes do produto...
            </div>
        );
    }

    // Renderiza a tela de erro se houver algum problema (incluindo status inativo)
    if (error) {
        return (
            <div className="flex flex-col items-center justify-center min-h-screen text-xl text-red-500 p-4 text-center">
                <FaCheckCircle className="text-6xl mb-4" /> {/* Use um ícone relevante para o erro */}
                <p>{error}</p>
                <button 
                    onClick={() => navigate(-1)} 
                    className="mt-6 px-8 py-3 bg-gray-200 rounded-md hover:bg-gray-300 transition-colors font-semibold flex items-center"
                >
                    <HiOutlineArrowLeft className="mr-2" /> Voltar
                </button>
            </div>
        );
    }

    if (!product) {
        return null;
    }

    return (
        <div className="bg-white min-h-screen p-8 font-poppins text-gray-800">
            <motion.div
                className="max-w-6xl mx-auto"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.5 }}
            >
                <button
                    onClick={() => navigate(-1)}
                    className="flex items-center text-green-600 hover:text-green-800 transition-colors mb-8 text-lg"
                >
                    <HiOutlineArrowLeft className="mr-2 text-2xl" /> Voltar
                </button>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
                    <div className="flex flex-col items-center">
                        <img src={product.image} alt={product.name} className="w-full max-w-lg rounded-xl shadow-lg" />
                        <div className="grid grid-cols-4 gap-4 mt-4 w-full max-w-lg">
                            {product.gallery.map((img, index) => (
                                <img
                                    key={index}
                                    src={img}
                                    alt={`Gallery thumbnail ${index + 1}`}
                                    className="w-full h-20 object-cover rounded-md cursor-pointer border-2 border-transparent hover:border-green-500 transition-colors"
                                    onClick={() => {/* Lógica para exibir imagem maior */}}
                                />
                            ))}
                        </div>
                    </div>

                    <div>
                        <span className="text-sm font-semibold text-gray-500">{product.category}</span>
                        <h1 className="text-4xl font-bold mt-2">{product.name}</h1>
                        <p className="text-xl text-gray-600 mt-2">Por {product.author}</p>
                        <p className="text-5xl font-extrabold text-green-600 mt-4">{product.price}</p>
                        
                        <div className="mt-6">
                            <h2 className="text-2xl font-semibold mb-2">Descrição</h2>
                            <p className="text-gray-700 leading-relaxed whitespace-pre-line">{product.description}</p>
                        </div>

                        <div className="mt-8 flex space-x-4">
                            <motion.button
                                className="flex-1 py-4 rounded-xl bg-green-600 text-white font-bold transition-colors hover:bg-green-700"
                                whileHover={{ scale: 1.02 }}
                                whileTap={{ scale: 0.98 }}
                            >
                                <HiOutlineShoppingCart className="inline-block mr-2 text-2xl" /> Adicionar ao Carrinho
                            </motion.button>
                        </div>
                    </div>
                </div>
            </motion.div>
        </div>
    );
};

export default ProductDetailPage;