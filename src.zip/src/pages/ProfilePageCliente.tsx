import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  HiOutlineUserCircle, HiOutlineCog, HiOutlineCreditCard, HiOutlineChartBar,
  HiPencil, HiCheckCircle, HiBan
} from "react-icons/hi";
import {
  FaUserEdit, FaHistory, FaShoppingCart, FaExchangeAlt,
} from "react-icons/fa";
import { BiPackage } from "react-icons/bi";
import { auth, db } from "../firebase/firebaseConfig";
import { onAuthStateChanged } from "firebase/auth";
import { doc, getDoc, collection, query, where, getDocs, updateDoc } from "firebase/firestore";
import { useNavigate } from "react-router-dom";

// Componente para os botões de aba
const TabButton: React.FC<{
  label: string;
  icon: React.ReactNode;
  isActive: boolean;
  onClick: () => void;
}> = ({ label, icon, isActive, onClick }) => (
  <motion.li
    className={`flex items-center gap-4 px-4 py-3 rounded-lg cursor-pointer transition-all ${
      isActive
        ? "bg-green-100 text-green-700 font-semibold"
        : "hover:bg-gray-50 text-gray-600"
    }`}
    onClick={onClick}
    whileHover={{ scale: 1.02 }}
    whileTap={{ scale: 0.98 }}
  >
    <div className="text-2xl">{icon}</div>
    <span>{label}</span>
  </motion.li>
);

const ProfilePageCliente: React.FC = () => {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [user, setUser] = useState<any>(null);
  const [clientData, setClientData] = useState<any>(null);
  const [myPurchases, setMyPurchases] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        await fetchClientData(currentUser.uid);
      } else {
        navigate("/login");
      }
    });
    return () => unsubscribe();
  }, [navigate]);

  const fetchClientData = async (uid: string) => {
    setLoading(true);
    try {
      const userRef = doc(db, "usuarios", uid);
      const userSnap = await getDoc(userRef);

      if (userSnap.exists()) {
        const userData = userSnap.data();
        setClientData({ ...userData });

        const purchasesQuery = query(collection(db, "purchases"), where("buyerId", "==", uid));
        const purchasesSnap = await getDocs(purchasesQuery);
        const purchasesList = purchasesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        setMyPurchases(purchasesList);
      } else {
        console.warn("Documento de usuário não encontrado.");
        setClientData({
          nome: "Novo Cliente",
          email: user?.email || "email@exemplo.com",
          telefone: "Não informado",
          endereco: "Não informado",
        });
        setMyPurchases([]);
      }
    } catch (error) {
      console.error("Erro ao buscar dados do cliente:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleSwitchUserType = async (newType: string) => {
    if (user && clientData.userType !== newType) {
      try {
        const userRef = doc(db, "usuarios", user.uid);
        await updateDoc(userRef, { userType: newType });
        setClientData((prevData: any) => ({ ...prevData, userType: newType }));
        navigate(newType === 'produtor' ? '/profile-produtor' : '/profile-cliente');
      } catch (error) {
        console.error("Erro ao mudar tipo de usuário:", error);
      }
    }
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center h-full">
          <p className="text-xl text-gray-600">Carregando dados...</p>
        </div>
      );
    }

    switch (activeTab) {
      case "dashboard":
        return <DashboardContentClient />;
      case "my-products":
        return <MyProductsContentClient myPurchases={myPurchases} />;
      case "personal-info":
        return <PersonalInformationClient clientData={clientData} />;
      case "settings":
        return <SettingsContentClient currentUserType={clientData?.userType} onSwitchUserType={handleSwitchUserType} />;
      default:
        return <DashboardContentClient />;
    }
  };

  const MyProductsContentClient: React.FC<{ myPurchases: any[] }> = ({ myPurchases }) => (
    <>
      <h3 className="text-3xl font-bold mb-6 text-gray-900">Meus Infoprodutos Comprados</h3>
      <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
        {myPurchases.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {myPurchases.map((purchase) => (
              <div key={purchase.id} className="bg-gray-50 p-4 rounded-lg shadow-md">
                <h5 className="font-bold text-gray-900">{purchase.productName}</h5>
                <p className="text-sm text-gray-600">Vendido por: {purchase.sellerName}</p>
                <p className="text-sm text-green-600 font-bold mt-2">Preço: MT {purchase.amount}</p>
                <p className="text-xs text-gray-500 mt-1">Data da compra: {new Date(purchase.date.seconds * 1000).toLocaleDateString()}</p>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center p-6 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
            <p className="font-semibold text-gray-600">Você ainda não comprou nenhum infoproduto.</p>
          </div>
        )}
      </div>
    </>
  );

  const DashboardContentClient: React.FC = () => (
    <>
      <h3 className="text-3xl font-bold mb-6 text-gray-900">Visão Geral do Cliente</h3>
      <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100 flex flex-col items-center">
        <p className="text-xl font-semibold text-gray-700">Bem-vindo(a) à sua área de cliente!</p>
        <p className="mt-2 text-gray-500">Navegue pelas abas para ver seus produtos comprados e gerenciar sua conta.</p>
        <FaShoppingCart className="text-6xl text-green-400 mt-6" />
      </div>
    </>
  );

  const PersonalInformationClient: React.FC<{ clientData: any }> = ({ clientData }) => (
    <>
      <h3 className="text-3xl font-bold mb-6 text-gray-900">Informações Pessoais</h3>
      <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100 space-y-6">
        <InputField
          label="Nome Completo"
          type="text"
          value={clientData?.nome || ""}
          readOnly
        />
        <InputField
          label="Email"
          type="email"
          value={clientData?.email || ""}
          readOnly
        />
        <InputField
          label="Telefone"
          type="text"
          value={clientData?.telefone || ""}
          readOnly
        />
        <InputField
          label="Endereço"
          type="text"
          value={clientData?.endereco || ""}
          readOnly
        />
        <motion.button
          className="w-full md:w-auto px-8 py-3 rounded-md bg-green-600 text-white font-bold transition-colors hover:bg-green-700"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Alterar Dados
        </motion.button>
      </div>
    </>
  );

  const InputField: React.FC<{
    label: string;
    type: string;
    value: string;
    readOnly?: boolean;
  }> = ({ label, type, value, readOnly = false }) => (
    <div>
      <label className="block text-gray-700 font-semibold mb-1">{label}</label>
      <input
        type={type}
        value={value}
        readOnly={readOnly}
        className={`w-full p-3 rounded-lg border border-gray-200 focus:outline-none ${
          readOnly
            ? "bg-gray-100 text-gray-500 cursor-not-allowed"
            : "bg-white focus:ring-2 focus:ring-green-500"
        }`}
      />
    </div>
  );

  const SettingsContentClient: React.FC<{ currentUserType: string, onSwitchUserType: (type: string) => void }> = ({ currentUserType, onSwitchUserType }) => (
    <>
      <h3 className="text-3xl font-bold mb-6 text-gray-900">Configurações da Conta</h3>
      <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100 space-y-6">
        <div>
          <h4 className="text-xl font-bold text-gray-900">Mudar Tipo de Usuário</h4>
          <p className="text-gray-600 mb-4">Você pode mudar para uma conta de afiliado ou produtor para vender infoprodutos.</p>
          <motion.button
            onClick={() => onSwitchUserType(currentUserType === 'cliente' ? 'produtor' : 'cliente')}
            className="px-6 py-3 rounded-md bg-purple-600 text-white font-bold transition-colors hover:bg-purple-700 flex items-center gap-2"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            <FaExchangeAlt /> Mudar para Produtor
          </motion.button>
        </div>
      </div>
    </>
  );

  return (
    <div className="bg-gray-100 min-h-screen font-poppins relative flex flex-col pt-24 md:pt-32">
      <div className="relative z-10 container mx-auto px-4 py-8">
        <motion.div
          className="bg-white rounded-2xl shadow-xl overflow-hidden p-6 md:p-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex flex-col md:flex-row gap-8">
            <nav className="flex-shrink-0 w-full md:w-64">
              <div className="flex flex-col items-center mb-6">
                <div className="w-24 h-24 rounded-full bg-gray-200 mb-4 flex items-center justify-center text-gray-400 text-6xl">
                  <HiOutlineUserCircle />
                </div>
                <h2 className="text-xl font-bold">
                  {clientData?.nome || "Carregando..."}
                </h2>
                <p className="text-sm text-gray-500">
                  {user?.email || "Carregando..."}
                </p>
              </div>
              <ul className="space-y-2">
                <TabButton
                  label="Dashboard"
                  icon={<HiOutlineChartBar />}
                  isActive={activeTab === "dashboard"}
                  onClick={() => setActiveTab("dashboard")}
                />
                <TabButton
                  label="Meus Infoprodutos"
                  icon={<BiPackage />}
                  isActive={activeTab === "my-products"}
                  onClick={() => setActiveTab("my-products")}
                />
                <TabButton
                  label="Informações Pessoais"
                  icon={<FaUserEdit />}
                  isActive={activeTab === "personal-info"}
                  onClick={() => setActiveTab("personal-info")}
                />
                <TabButton
                  label="Configurações"
                  icon={<HiOutlineCog />}
                  isActive={activeTab === "settings"}
                  onClick={() => setActiveTab("settings")}
                />
              </ul>
            </nav>

            <div className="flex-grow">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  {renderContent()}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default ProfilePageCliente;