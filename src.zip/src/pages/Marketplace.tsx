import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { HiOutlineBookOpen, HiOutlineVideoCamera, HiOutlineLightBulb, HiOutlineShoppingCart, HiOutlineUserCircle, HiOutlineX, HiCheckCircle, HiExclamationCircle, HiOutlineSearch } from 'react-icons/hi';
import { FaCheckCircle } from 'react-icons/fa';
import { onAuthStateChanged, User } from 'firebase/auth';
import { auth, db } from '../firebase/firebaseConfig';
import { useNavigate, Link } from 'react-router-dom';
import { collection, getDocs, query, where } from 'firebase/firestore';

// Definição da interface para os dados do produto
interface Product {
    id: string;
    name: string;
    price: string;
    author: string;
    image: string;
    category: string;
    description: string;
    gallery: string[];
}

// Definição da interface para as notificações
interface Notification {
    message: string;
    type: 'success' | 'error' | 'info';
}

const categories = [
    { name: 'Todos', icon: HiOutlineLightBulb },
    { name: 'E-books', icon: HiOutlineBookOpen },
    { name: 'Cursos', icon: HiOutlineVideoCamera },
    { name: 'Webinars', icon: HiOutlineLightBulb },
    { name: 'Templates', icon: HiOutlineLightBulb },
];

const MarketplacePage: React.FC = () => {
    const [products, setProducts] = useState<Product[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedCategory, setSelectedCategory] = useState('Todos');
    const [searchQuery, setSearchQuery] = useState('');
    const [cartItems, setCartItems] = useState<Product[]>([]);
    const [isCartOpen, setIsCartOpen] = useState(false);
    const [user, setUser] = useState<User | null>(null);
    const [notification, setNotification] = useState<Notification | null>(null);
    const navigate = useNavigate();

    // Hook para buscar os produtos no Firestore
    useEffect(() => {
        const fetchProducts = async () => {
            try {
                // Filtra apenas produtos com status 'active'
                const productsQuery = query(
                    collection(db, 'products'),
                    where('status', '==', 'Ativo') // Verifica se o campo 'status' é igual a 'active'
                );
                
                // Se 'active' não funcionar, tente o seguinte:
                // const productsQuery = query(
                //     collection(db, 'products'),
                //     where('status', '==', 'ativo') // Se o valor for 'ativo'
                // );

                const productsSnapshot = await getDocs(productsQuery);
                const productsList: Product[] = productsSnapshot.docs.map(doc => {
                    const data = doc.data();
                    return {
                        id: doc.id,
                        name: data.productName,
                        price: `MT ${data.price.toLocaleString('pt-MZ')}`,
                        author: data.authorId,
                        image: data.coverImageUrl,
                        category: data.productType === 'livro' ? 'E-books' : 'Cursos',
                        description: data.description,
                        gallery: [data.coverImageUrl, ...data.fileUrls.filter((url: string) => url.endsWith('.jpg') || url.endsWith('.png') || url.endsWith('.jpeg'))]
                    };
                });
                setProducts(productsList);
            } catch (error) {
                console.error("Erro ao buscar produtos:", error);
                showNotification('Falha ao carregar produtos.', 'error');
            } finally {
                setLoading(false);
            }
        };

        fetchProducts();
    }, []);

    // Hook para monitorar o estado de autenticação do usuário
    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
            setUser(currentUser);
        });
        return () => unsubscribe();
    }, []);

    // Hook para gerenciar as notificações
    useEffect(() => {
        if (notification) {
            const timer = setTimeout(() => {
                setNotification(null);
            }, 3000);
            return () => clearTimeout(timer);
        }
    }, [notification]);

    // Função para exibir uma notificação
    const showNotification = (message: string, type: 'success' | 'error' | 'info') => {
        setNotification({ message, type });
    };

    // Filtra os produtos com base na categoria e pesquisa
    const filteredProducts = products.filter(product => {
        const matchesCategory = selectedCategory === 'Todos' || product.category === selectedCategory;
        const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) || product.description.toLowerCase().includes(searchQuery.toLowerCase());
        return matchesCategory && matchesSearch;
    });

    // Adiciona um item ao carrinho
    const addItemToCart = (product: Product) => {
        if (!user) {
            showNotification('Para adicionar itens, você precisa estar logado.', 'error');
            setTimeout(() => navigate('/login'), 2000);
            return;
        }

        const isAlreadyInCart = cartItems.some(item => item.id === product.id);
        if (isAlreadyInCart) {
            showNotification('Este item já está no seu carrinho.', 'info');
            return;
        }

        setCartItems(prevItems => [...prevItems, product]);
        showNotification(`${product.name} foi adicionado ao carrinho!`, 'success');
    };

    // Remove um item do carrinho
    const removeItemFromCart = (productId: string) => {
        setCartItems(prevItems => prevItems.filter(item => item.id !== productId));
    };

    return (
        <div className="bg-gradient-to-br from-green-50 to-white text-gray-800 min-h-screen font-poppins relative overflow-hidden">
            {/* Sistema de notificação */}
            <AnimatePresence>
                {notification && (
                    <motion.div
                        className={`fixed top-6 right-6 z-50 p-4 rounded-lg shadow-md flex items-center space-x-3 text-white ${
                            notification.type === 'success' ? 'bg-green-500' : notification.type === 'error' ? 'bg-red-500' : 'bg-blue-500'
                        }`}
                        initial={{ opacity: 0, x: 200 }}
                        animate={{ opacity: 1, x: 0 }}
                        exit={{ opacity: 0, x: 200 }}
                        transition={{ duration: 0.5 }}
                    >
                        {notification.type === 'success' && <HiCheckCircle className="text-2xl" />}
                        {notification.type === 'error' && <HiExclamationCircle className="text-2xl" />}
                        <span className="font-semibold">{notification.message}</span>
                        <button onClick={() => setNotification(null)} className="text-white ml-2">
                            <HiOutlineX />
                        </button>
                    </motion.div>
                )}
            </AnimatePresence>

            {/* Background de pontos */}
            <div
                className="fixed inset-0 z-0 opacity-10"
                style={{
                    backgroundImage: 'radial-gradient(circle, #22c55e 1px, transparent 1px)',
                    backgroundSize: '20px 20px',
                    animation: 'background-pan 30s linear infinite',
                }}
            ></div>
            <style>
                {`
                    @keyframes background-pan {
                        from { background-position: 0% 0%; }
                        to { background-position: 100% 100%; }
                    }
                `}
            </style>

            {/* Hero Section do Marketplace */}
            <section className="relative z-10 py-32 px-4 md:px-8 text-center">
                <motion.div
                    initial={{ opacity: 0, y: 50 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.8 }}
                >
                    <h1 className="text-5xl sm:text-6xl md:text-7xl font-bold leading-tight bg-clip-text text-transparent bg-gradient-to-r from-green-600 to-emerald-400">
                        Encontre o Infoproduto Certo
                    </h1>
                    <p className="mt-4 text-xl sm:text-2xl text-gray-700 max-w-3xl mx-auto">
                        Explore uma vasta seleção de e-books, cursos e templates para impulsionar seu conhecimento e negócio.
                    </p>
                </motion.div>
            </section>

            {/* Botões flutuantes */}
            <div className="fixed top-6 right-6 z-40 flex items-center space-x-4">
                {user && (
                    <motion.button
                        className="bg-gray-200 text-gray-700 p-3 rounded-full shadow-lg hover:bg-gray-300 transition-colors"
                        onClick={() => navigate('/perfil')}
                        whileHover={{ scale: 1.1 }}
                        whileTap={{ scale: 0.9 }}
                    >
                        <HiOutlineUserCircle className="text-2xl" />
                    </motion.button>
                )}
                <motion.button
                    className="relative bg-green-600 text-white p-3 rounded-full shadow-lg hover:bg-green-700 transition-colors"
                    onClick={() => setIsCartOpen(true)}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                >
                    <HiOutlineShoppingCart className="text-2xl" />
                    {cartItems.length > 0 && (
                        <span className="absolute top-0 right-0 transform translate-x-1/2 -translate-y-1/2 bg-red-500 text-white text-xs font-bold rounded-full h-5 w-5 flex items-center justify-center">
                            {cartItems.length}
                        </span>
                    )}
                </motion.button>
            </div>
            
            {/* Seção de Filtros e Produtos */}
            <section className="relative z-10 px-4 md:px-8 pb-20">
                <div className="container mx-auto">
                    {/* Barra de Pesquisa e Filtros */}
                    <div className="flex flex-col md:flex-row justify-center items-center gap-4 mb-12">
                        <div className="relative w-full md:w-1/2">
                             <HiOutlineSearch className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 text-lg" />
                             <input
                                 type="text"
                                 placeholder="Pesquisar produtos..."
                                 className="w-full p-3 pl-12 rounded-lg shadow-md focus:outline-none focus:ring-2 focus:ring-green-500 transition-all text-gray-800 bg-white"
                                 value={searchQuery}
                                 onChange={(e) => setSearchQuery(e.target.value)}
                            />
                        </div>
                        <div className="flex flex-wrap justify-center gap-2 mt-4 md:mt-0">
                            {categories.map((category) => (
                                <motion.button
                                    key={category.name}
                                    onClick={() => setSelectedCategory(category.name)}
                                    className={`flex items-center gap-2 px-4 py-2 rounded-full font-semibold transition-colors ${
                                        selectedCategory === category.name
                                            ? 'bg-green-600 text-white shadow-md'
                                            : 'bg-white text-gray-700 hover:bg-gray-100'
                                    }`}
                                    whileHover={{ scale: 1.05 }}
                                    whileTap={{ scale: 0.95 }}
                                >
                                    <category.icon className="text-xl" />
                                    {category.name}
                                </motion.button>
                            ))}
                        </div>
                    </div>

                    {/* Grid de Produtos */}
                    {loading ? (
                        <p className="text-center text-lg text-gray-600 mt-12">Carregando produtos...</p>
                    ) : (
                        filteredProducts.length > 0 ? (
                            <motion.div
                                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8"
                                initial="hidden"
                                animate="visible"
                                variants={{
                                    hidden: { opacity: 0 },
                                    visible: {
                                        opacity: 1,
                                        transition: {
                                            staggerChildren: 0.1,
                                        },
                                    },
                                }}
                            >
                                {filteredProducts.map((product: Product) => (
                                    <motion.div
                                        key={product.id}
                                        className="bg-white p-6 rounded-xl shadow-xl hover:shadow-2xl transition-shadow flex flex-col justify-between h-full"
                                        variants={{
                                            hidden: { opacity: 0, scale: 0.8 },
                                            visible: { opacity: 1, scale: 1 },
                                        }}
                                        whileHover={{ y: -5 }}
                                        whileTap={{ scale: 0.98 }}
                                    >
                                        {/* AQUI ESTÁ A LIGAÇÃO PARA A PÁGINA DE DETALHES */}
                                        <Link to={`/product/${product.id}`} className="block cursor-pointer">
                                            <img src={product.image} alt={product.name} className="w-full h-48 object-cover rounded-md mb-4" />
                                            <div className="flex items-center justify-between text-sm text-gray-500 mb-2">
                                                <span className="font-semibold">{product.category}</span>
                                                <span>Por {product.author}</span>
                                            </div>
                                            <h3 className="text-2xl font-bold text-gray-900 mb-2">{product.name}</h3>
                                            <p className="text-4xl font-extrabold text-green-600 mb-4">{product.price}</p>
                                        </Link>
                                        <motion.button
                                            onClick={() => addItemToCart(product)}
                                            className="w-full py-3 rounded-md bg-green-600 text-white font-bold transition-colors hover:bg-green-700 mt-auto"
                                            whileHover={{ scale: 1.02 }}
                                            whileTap={{ scale: 0.98 }}
                                        >
                                            Adicionar ao Carrinho
                                        </motion.button>
                                    </motion.div>
                                ))}
                            </motion.div>
                        ) : (
                            <p className="text-center text-lg text-gray-600 mt-12">Nenhum produto encontrado.</p>
                        )
                    )}
                </div>
            </section>
        </div>
    );
};

export default MarketplacePage;