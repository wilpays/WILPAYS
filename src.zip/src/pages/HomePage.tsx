import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { auth } from '../firebase/firebaseConfig';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { motion, AnimatePresence } from 'framer-motion';
import { HiOutlineChartBar, HiOutlineCurrencyDollar, HiOutlineShieldCheck, HiOutlinePencil, HiOutlineChatAlt2, HiOutlinePhone } from 'react-icons/hi';
import { BsCheckCircleFill } from 'react-icons/bs';
import { FaMoneyBillWave, FaMobileAlt } from 'react-icons/fa';

// Dados dos slides para a seção Hero
const heroSlides = [
  {
    title: 'Transforme sua presença online',
    description: 'Soluções de marketing digital que impulsionam seu negócio.',
    buttonText: 'Começar agora',
    link: '/marketplace',
  },
  {
    title: 'Alcance novos clientes',
    description: 'Estratégias otimizadas para o seu crescimento.',
    buttonText: 'Explorar soluções',
    link: '/marketplace',
  },
  {
    title: 'Seja visto. Seja lembrado.',
    description: 'Aumente seu tráfego e conversões com a Wilpays.',
    buttonText: 'Saiba mais',
    link: '/marketplace',
  },
];

const HomePage: React.FC = () => {
  const [usuarioLogado, setUsuarioLogado] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [currentSlide, setCurrentSlide] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUsuarioLogado(!!user);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prevSlide) => (prevSlide + 1) % heroSlides.length);
    }, 5000); // Muda a cada 5 segundos
    return () => clearInterval(interval);
  }, []);

  const handleLogout = async () => {
    await signOut(auth);
    navigate('/login');
  };

  const menuItems = [
    { name: 'Página inicial', id: 'inicio', link: '/#inicio' },
    { name: 'Loja', id: 'loja', link: '/marketplace' }, 
    { name: 'Taxas', id: 'taxas', link: '/#taxas' },
    { name: 'Planos', id: 'planos', link: '/#planos' },
    { name: 'Serviços', id: 'servicos', link: '/#servicos' },
    { name: 'Pagamentos', id: 'pagamentos', link: '/#pagamentos' },
  ];

  // Função unificada de navegação
  const handleNavigation = (link: string, id?: string) => {
    if (link.startsWith('/#')) {
      // Rola para a seção na mesma página
      const targetId = link.replace('/#', '');
      const section = document.getElementById(targetId);
      if (section) {
        section.scrollIntoView({ behavior: 'smooth' });
      }
    } else {
      // Usa navigate para links de outras páginas
      navigate(link);
    }
    setIsMenuOpen(false); // Fecha o menu mobile após a navegação
  };

  return (
    <div className="bg-gradient-to-br from-green-50 to-white text-gray-800 min-h-screen font-poppins relative overflow-hidden">
      {/* Background animado de pontos */}
      <div
        className="fixed inset-0 z-0 opacity-10"
        style={{
          backgroundImage: 'radial-gradient(circle, #22c55e 1px, transparent 1px)', // Cor do ponto verde
          backgroundSize: '20px 20px',
          animation: 'background-pan 30s linear infinite',
        }}
      ></div>
      <style>
        {`
          @keyframes background-pan {
            from { background-position: 0% 0%; }
            to { background-position: 100% 100%; }
          }
        `}
      </style>

      {/* Navbar */}
      <header className="fixed top-0 left-0 right-0 z-20 flex justify-between items-center py-6 px-8 bg-white/80 backdrop-blur-md md:px-12 shadow-sm">
        <div className="text-2xl font-bold text-gray-900 z-50">
          <a href="/">Wilpays</a>
        </div>

        {/* Botão do Menu Hambúrguer (Mobile) */}
        <button className="md:hidden z-50 text-gray-900 focus:outline-none" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isMenuOpen ? 'M6 18L18 6M6 6l12 12' : 'M4 6h16M4 12h16m-7 6h7'} />
          </svg>
        </button>

        {/* Menu e Botões (Desktop) */}
        <div className="hidden md:flex flex-grow justify-center">
          <nav className="flex space-x-8">
            {menuItems.map((item) => (
              <a 
                key={item.id} 
                className="font-semibold cursor-pointer hover:text-green-600 transition-colors"
                onClick={() => handleNavigation(item.link, item.id)}
              >
                {item.name}
              </a>
            ))}
          </nav>
        </div>
        <div className="hidden md:flex space-x-4">
          {usuarioLogado ? (
            <>
              <motion.button onClick={() => navigate('/perfil')} className="px-6 py-2 rounded-md border-2 border-green-500 text-green-500 font-semibold hover:bg-green-500 hover:text-white transition-colors" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>Perfil</motion.button>
              <motion.button onClick={handleLogout} className="px-6 py-2 rounded-md bg-green-500 text-white font-semibold hover:bg-green-600 transition-colors" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>Sair</motion.button>
            </>
          ) : (
            <motion.button onClick={() => navigate('/login')} className="px-6 py-2 rounded-md bg-green-500 text-white font-semibold hover:bg-green-600 transition-colors" whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>Iniciar sessão</motion.button>
          )}
        </div>

        {/* Menu Dropdown (Mobile) */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              className="md:hidden fixed inset-0 z-40 bg-white/90 backdrop-blur-md flex flex-col items-center justify-center space-y-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
            >
              <nav className="flex flex-col items-center space-y-6 text-xl">
                {menuItems.map((item) => (
                  <a 
                    key={item.id} 
                    className="font-semibold text-gray-900 hover:text-green-600 transition-colors"
                    onClick={() => handleNavigation(item.link, item.id)}
                  >
                    {item.name}
                  </a>
                ))}
              </nav>
              <div className="flex flex-col space-y-4 pt-4">
                {usuarioLogado ? (
                  <>
                    <button onClick={() => { navigate('/perfil'); setIsMenuOpen(false); }} className="px-8 py-3 rounded-md border-2 border-green-500 text-green-500 font-semibold">Perfil</button>
                    <button onClick={() => { handleLogout(); setIsMenuOpen(false); }} className="px-8 py-3 rounded-md bg-green-500 text-white font-semibold">Sair</button>
                  </>
                ) : (
                  <button onClick={() => { navigate('/login'); setIsMenuOpen(false); }} className="px-8 py-3 rounded-md bg-green-500 text-white font-semibold">Iniciar sessão</button>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>

      {/* Conteúdo Principal da Página (Seções Roláveis) */}
      <main className="relative z-10 pt-24 md:pt-32">
        {/* Seção 1: Página Inicial (Hero com slides e gradiente no título) */}
        <section id="inicio" className="min-h-screen flex items-center justify-center text-center px-4">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentSlide}
              className="flex flex-col items-center min-h-[150px]"
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -50 }}
              transition={{ duration: 0.8 }}
            >
              <motion.h1
                className="text-5xl sm:text-6xl md:text-7xl font-bold leading-tight bg-clip-text text-transparent bg-gradient-to-r from-green-600 to-emerald-400" // Gradiente verde/esmeralda
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.2 }}
              >
                {heroSlides[currentSlide].title}
              </motion.h1>
              <motion.p
                className="mt-4 text-xl sm:text-2xl md:text-3xl text-gray-700 max-w-2xl"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ delay: 0.4 }}
              >
                {heroSlides[currentSlide].description}
              </motion.p>
              <motion.div
                className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 0.5, duration: 0.6 }}
              >
                <motion.button
                  onClick={() => navigate(heroSlides[currentSlide].link)}
                  className="px-8 py-3 md:px-12 md:py-4 rounded-full bg-green-600 text-white text-lg md:text-xl font-bold shadow-lg hover:bg-green-700 transition-all"
                  whileHover={{ scale: 1.05, boxShadow: '0 6px 20px rgba(34, 197, 94, 0.4)' }}
                  whileTap={{ scale: 0.95 }}
                >
                  {heroSlides[currentSlide].buttonText}
                </motion.button>
                <motion.button
                  onClick={() => navigate('/marketplace')}
                  className="px-8 py-3 md:px-12 md:py-4 rounded-full border-2 border-green-500 text-green-600 text-lg md:text-xl font-bold hover:bg-green-100 transition-all"
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  Visitar Loja
                </motion.button>
              </motion.div>
            </motion.div>
          </AnimatePresence>
        </section>

        {/* Seção 2: Taxas */}
        <section id="taxas" className="min-h-screen flex items-center justify-center py-20 px-4 md:px-8 bg-green-50">
          <div className="container mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">Taxas Transparentes, Crescimento sem Limites</h2>
            <p className="text-lg md:text-xl text-gray-700 max-w-3xl mx-auto mb-12">
              Nossa estrutura de taxas é simples e justa, projetada para que você possa focar no que realmente importa: o seu negócio.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {[
                { title: 'Taxa de Transação', icon: <HiOutlineCurrencyDollar className="text-4xl text-green-600" />, desc: 'Cobranças fixas e previsíveis por cada transação concluída. Sem surpresas.' },
                { title: 'Segurança Garantida', icon: <HiOutlineShieldCheck className="text-4xl text-green-600" />, desc: 'Tecnologia avançada para proteger seus dados e de seus clientes, sem custo adicional.' },
                { title: 'Suporte 24/7', icon: <HiOutlineChatAlt2 className="text-4xl text-green-600" />, desc: 'Nossa equipe de suporte está disponível a qualquer momento para ajudar você, 24 horas por dia.' },
              ].map((card, index) => (
                <motion.div
                  key={index}
                  className="bg-white p-8 rounded-lg shadow-xl text-gray-800"
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true, amount: 0.2 }}
                >
                  <div className="mb-4">{card.icon}</div>
                  <h3 className="text-2xl font-semibold mb-2">{card.title}</h3>
                  <p className="text-gray-700">{card.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Seção 3: Planos */}
        <section id="planos" className="min-h-screen flex items-center justify-center py-20 px-4 md:px-8 bg-green-100">
          <div className="container mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">Escolha o Plano Ideal para Você</h2>
            <p className="text-lg md:text-xl text-gray-700 max-w-3xl mx-auto mb-12">
              Nossos planos são flexíveis e se adaptam ao tamanho do seu negócio, seja você um iniciante ou uma grande empresa.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-end">
              {[
                { name: 'Básico', price: 'MT 2.500', features: ['Até 1.000 clientes', 'Suporte Padrão', 'Relatórios Mensais'], cta: 'Começar agora' },
                { name: 'Pro', price: 'MT 7.500', features: ['Clientes ilimitados', 'Suporte Prioritário', 'Análises Avançadas', 'Integrações'], cta: 'Assinar agora', highlight: true },
                { name: 'Empresarial', price: 'Personalizado', features: ['Tudo do Pro', 'Gerente de Contas', 'Consultoria Exclusiva', 'Segurança Personalizada'], cta: 'Fale conosco' },
              ].map((plan, index) => (
                <motion.div
                  key={index}
                  className={`p-8 rounded-lg shadow-xl text-center ${plan.highlight ? 'bg-green-600 text-white transform scale-105' : 'bg-white text-gray-800'}`}
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true, amount: 0.2 }}
                >
                  <h3 className="text-3xl font-bold mb-2">{plan.name}</h3>
                  <p className={`text-5xl font-extrabold mb-4 ${plan.highlight ? 'text-white' : 'text-green-600'}`}>{plan.price}</p>
                  <ul className="mb-6 space-y-2 text-left px-4">
                    {plan.features.map((feature, i) => (
                      <li key={i} className="flex items-center gap-2">
                        <BsCheckCircleFill className={`text-xl ${plan.highlight ? 'text-white' : 'text-green-500'}`} />
                        <span className={`${plan.highlight ? 'text-white' : 'text-gray-700'}`}>{feature}</span>
                      </li>
                    ))}
                  </ul>
                  <button className={`w-full py-3 rounded-md font-bold transition-colors ${plan.highlight ? 'bg-white text-green-600 hover:bg-gray-100' : 'bg-green-600 text-white hover:bg-green-700'}`}>
                    {plan.cta}
                  </button>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Seção 4: Serviços */}
        <section id="servicos" className="min-h-screen flex items-center justify-center py-20 px-4 md:px-8 bg-green-50">
          <div className="container mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">Nossos Serviços de Marketing Digital</h2>
            <p className="text-lg md:text-xl text-gray-700 max-w-3xl mx-auto mb-12">
              Oferecemos um leque completo de soluções para garantir sua visibilidade e sucesso online.
            </p>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
              {[
                { title: 'Otimização SEO', icon: <HiOutlineChartBar className="text-5xl text-green-600 mx-auto mb-4" />, desc: 'Aumente seu ranking em mecanismos de busca e gere tráfego orgânico de alta qualidade.' },
                { title: 'Marketing de Conteúdo', icon: <HiOutlinePencil className="text-5xl text-green-600 mx-auto mb-4" />, desc: 'Crie narrativas envolventes que atraem e convertem seu público-alvo.' },
                { title: 'Anúncios Pagos', icon: <HiOutlinePhone className="text-5xl text-green-600 mx-auto mb-4" />, desc: 'Campanhas de anúncios estratégicas no Google e redes sociais para maximizar seu ROI.' },
              ].map((service, index) => (
                <motion.div
                  key={index}
                  className="bg-white p-8 rounded-lg shadow-xl text-center text-gray-800"
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true, amount: 0.2 }}
                >
                  {service.icon}
                  <h3 className="text-2xl font-semibold mb-2">{service.title}</h3>
                  <p className="text-gray-700">{service.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* Seção 5: Pagamentos */}
        <section id="pagamentos" className="min-h-screen flex items-center justify-center py-20 px-4 md:px-8 bg-green-100">
          <div className="container mx-auto text-center">
            <h2 className="text-3xl md:text-4xl font-bold mb-4 text-gray-900">Opções de Pagamento</h2>
            <p className="text-lg md:text-xl text-gray-700 max-w-3xl mx-auto mb-12">
              Oferecemos métodos de pagamento flexíveis e seguros, adaptados à realidade do mercado.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
              {[
                { title: 'M-pesa', icon: <FaMobileAlt className="text-5xl text-green-600 mx-auto mb-4" />, desc: 'Pague de forma rápida e segura através do seu telemóvel usando o serviço M-pesa. Sem complicações, sem taxas escondidas.' },
                { title: 'eMola', icon: <FaMoneyBillWave className="text-5xl text-green-600 mx-auto mb-4" />, desc: 'O sistema de pagamento eMola oferece transações instantâneas e confiáveis, ideal para o seu dia a dia.' },
              ].map((payment, index) => (
                <motion.div
                  key={index}
                  className="bg-white p-8 rounded-lg shadow-xl text-center text-gray-800"
                  initial={{ opacity: 0, y: 50 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.2 }}
                  viewport={{ once: true, amount: 0.2 }}
                >
                  {payment.icon}
                  <h3 className="text-2xl font-semibold mb-2">{payment.title}</h3>
                  <p className="text-gray-700">{payment.desc}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      </main>

      {/* Rodapé */}
      <footer className="bg-gray-800 text-center py-6 px-4 border-t border-gray-700 mt-12 text-gray-300">
        <p>&copy; 2025 Wilpays. Todos os direitos reservados.</p>
      </footer>
    </div>
  );
};

export default HomePage;