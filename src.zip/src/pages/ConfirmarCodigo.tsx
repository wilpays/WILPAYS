import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { auth, db } from "../firebase/firebaseConfig";
import { createUserWithEmailAndPassword } from "firebase/auth";
import { doc, setDoc } from "firebase/firestore";

const ConfirmarCodigo = () => {
  const [codigoDigitado, setCodigoDigitado] = useState("");
  const [erro, setErro] = useState("");
  const [carregando, setCarregando] = useState(false);
  const [emailDestino, setEmailDestino] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    const dadosRaw = localStorage.getItem("signupData");
    if (dadosRaw) {
      const dados = JSON.parse(dadosRaw);
      setEmailDestino(dados.email);
    }
  }, []);

  const handleConfirmar = async () => {
    setErro("");
    setCarregando(true);

    const codigoSalvo = localStorage.getItem("codigoVerificacao");
    const dadosRaw = localStorage.getItem("signupData");

    if (!dadosRaw || !codigoSalvo) {
      setErro("Dados de cadastro não encontrados. Volte e preencha o formulário novamente.");
      setCarregando(false);
      return;
    }

    const dados = JSON.parse(dadosRaw);

    if (codigoDigitado !== codigoSalvo) {
      setErro("Código incorreto. Verifique seu email e tente novamente.");
      setCarregando(false);
      return;
    }

    try {
      const userCredential = await createUserWithEmailAndPassword(auth, dados.email, dados.senha);
      const uid = userCredential.user.uid;

      await setDoc(doc(db, "usuarios", uid), {
        nome: dados.nome,
        email: dados.email,
        genero: dados.genero,
        idade: Number(dados.idade),
        telefone: dados.telefone,
        endereco: dados.endereco,
        tipoUsuario: dados.tipoUsuario,
        senha: dados.senha,
        criadoEm: new Date(),
      });

      localStorage.removeItem("signupData");
      localStorage.removeItem("codigoVerificacao");

      navigate("/sucesso");
    } catch (error: any) {
      console.error("Erro ao registrar usuário:", error);
      setErro("Erro ao registrar usuário. Verifique se o email já está em uso.");
    } finally {
      setCarregando(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-md bg-white shadow-lg rounded-xl p-8">
        <h2 className="text-2xl font-semibold text-gray-800 mb-2 text-center">Confirmação de Código</h2>
        <p className="text-sm text-gray-600 mb-6 text-center">
          Digite o código que foi enviado para <span className="font-medium text-blue-600">{emailDestino}</span>.
        </p>

        <input
          type="text"
          placeholder="Código de verificação"
          value={codigoDigitado}
          onChange={(e) => setCodigoDigitado(e.target.value)}
          className="w-full border border-gray-300 rounded-md px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 mb-4"
        />

        <button
          onClick={handleConfirmar}
          disabled={carregando || !codigoDigitado}
          className={`w-full py-2 rounded-md text-white font-medium transition ${
            carregando || !codigoDigitado
              ? "bg-blue-300 cursor-not-allowed"
              : "bg-blue-600 hover:bg-blue-700"
          }`}
        >
          {carregando ? "Confirmando..." : "Confirmar"}
        </button>

        <button
          onClick={() => navigate(-1)}
          className="w-full mt-4 py-2 text-sm text-gray-600 hover:text-blue-600 transition"
        >
          ← Voltar
        </button>

        {erro && <p className="text-red-600 text-sm mt-4 text-center">{erro}</p>}
      </div>
    </div>
  );
};

export default ConfirmarCodigo;
