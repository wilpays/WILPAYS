import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  HiOutlineUserCircle,
  HiOutlineCog,
  HiOutlineCreditCard,
  HiOutlineChartBar,
  HiOutlineTrash,
  HiPencil,
  HiCheckCircle,
  HiBan,
} from "react-icons/hi";
import {
  FaUserEdit,
  FaHistory,
  FaPlusCircle,
  FaDollarSign,
} from "react-icons/fa";
import { BiPackage } from "react-icons/bi";
import { auth, db } from "../firebase/firebaseConfig";
import { onAuthStateChanged } from "firebase/auth";
import {
  doc,
  getDoc,
  collection,
  query,
  where,
  getDocs,
  deleteDoc,
  updateDoc,
} from "firebase/firestore";
import { useNavigate } from "react-router-dom";
import CreateProductForm from "./components/CreateProductForm";
import Sidebar from "./components/profile/Sidebar";
import DashboardContent from "./components/profile/DashboardContent";
import MyProductsContent from "./components/profile/MyProductsContent";
import EarningsHistoryContent from "./components/profile/EarningsHistoryContent";
import PersonalInformation from "./components/profile/PersonalInformation";
import BillingContent from "./components/profile/BillingContent";
import SettingsContent from "./components/profile/SettingsContent";
import ConfirmModal from "./components/profile/ConfirmModal";

const ProfilePage: React.FC = () => {
  const [activeTab, setActiveTab] = useState("dashboard");
  const [user, setUser] = useState<any>(null);
  const [producerData, setProducerData] = useState<any>(null);
  const [myProducts, setMyProducts] = useState<any[]>([]);
  const [earningsHistory, setEarningsHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showProductForm, setShowProductForm] = useState(false);
  const [selectedProductForEdit, setSelectedProductForEdit] =
    useState<any>(null);
  const [showConfirmModal, setShowConfirmModal] = useState(false);
  const [productToDelete, setProductToDelete] = useState<string | null>(null);
  const navigate = useNavigate();

  const fetchUserData = async (uid: string) => {
    setLoading(true);
    try {
      const userRef = doc(db, "usuarios", uid);
      const userSnap = await getDoc(userRef);

      if (userSnap.exists()) {
        const userData = userSnap.data();
        setProducerData({
          ...userData,
          totalSales: userData.totalSales || 0,
          totalEarnings: userData.totalEarnings || 0,
          productsSold: userData.productsSold || 0,
          availableBalance: userData.availableBalance || 0,
        });

        const myProductsQuery = query(
          collection(db, "products"),
          where("authorId", "==", uid)
        );
        const myProductsSnap = await getDocs(myProductsQuery);
        const productsList = myProductsSnap.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setMyProducts(productsList);

        const earningsQuery = query(
          collection(db, "sales"),
          where("sellerId", "==", uid)
        );
        const earningsSnap = await getDocs(earningsQuery);
        const earningsList = earningsSnap.docs.map((doc) => ({
          id: doc.id,
          ...doc.data(),
        }));
        setEarningsHistory(earningsList);
      } else {
        console.warn("Documento de usuário não encontrado.");
        setProducerData({
          nome: "Novo Produtor",
          email: user?.email || "email@exemplo.com",
          totalSales: 0,
          totalEarnings: 0,
          productsSold: 0,
          availableBalance: 0,
          telefone: "Não informado",
          endereco: "Não informado",
        });
        setMyProducts([]);
        setEarningsHistory([]);
      }
    } catch (error) {
      console.error("Erro ao buscar dados do usuário:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        await fetchUserData(currentUser.uid);
      } else {
        navigate("/login");
      }
    });
    return () => unsubscribe();
  }, [navigate]);

  const handleProductCreated = () => {
    setShowProductForm(false);
    setSelectedProductForEdit(null);
    if (user) {
      fetchUserData(user.uid);
    }
  };

  const handleEditProduct = (product: any) => {
    setSelectedProductForEdit(product);
    setShowProductForm(true);
  };

  const handleToggleStatus = async (
    productId: string,
    currentStatus: string
  ) => {
    const productRef = doc(db, "products", productId);
    const newStatus = currentStatus === "Ativo" ? "Inativo" : "Ativo";
    try {
      await updateDoc(productRef, { status: newStatus });
      if (user) fetchUserData(user.uid); // Recarrega os dados para refletir a mudança
    } catch (error) {
      console.error("Erro ao alternar status do produto:", error);
    }
  };

  const handleDeleteProduct = (productId: string) => {
    setProductToDelete(productId);
    setShowConfirmModal(true);
  };

  const confirmDelete = async () => {
    if (productToDelete) {
      try {
        await deleteDoc(doc(db, "products", productToDelete));
        if (user) fetchUserData(user.uid); // Recarrega a lista de produtos
      } catch (error) {
        console.error("Erro ao apagar o produto:", error);
      } finally {
        setShowConfirmModal(false);
        setProductToDelete(null);
      }
    }
  };

  const renderContent = () => {
    if (loading) {
      return (
        <div className="flex justify-center items-center h-full">
          <p className="text-xl text-gray-600">Carregando dados...</p>
        </div>
      );
    }

    switch (activeTab) {
      case "dashboard":
        return <DashboardContent producerData={producerData} />;
      case "my-products":
        return (
          <MyProductsContent
            myProducts={myProducts}
            setShowProductForm={setShowProductForm}
            handleEdit={handleEditProduct}
            handleToggleStatus={handleToggleStatus}
            handleDelete={handleDeleteProduct}
          />
        );
      case "earnings":
        return <EarningsHistoryContent earningsHistory={earningsHistory} />;
      case "personal-info":
        return (
          <PersonalInformation
            producerData={producerData}
            user={user}
            onDataUpdated={() => fetchUserData(user.uid)}
          />
        );
      case "billing":
        return <BillingContent />;
      case "settings":
        return <SettingsContent />;
      default:
        return <DashboardContent producerData={producerData} />;
    }
  };

  return (
    <div className="bg-gray-100 min-h-screen font-poppins relative flex flex-col pt-24 md:pt-32">
      <div className="relative z-10 container mx-auto px-4 py-8">
        <motion.div
          className="bg-white rounded-2xl shadow-xl overflow-hidden p-6 md:p-12"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <div className="flex flex-col md:flex-row gap-8">
            <Sidebar
              producerData={producerData}
              user={user}
              activeTab={activeTab}
              setActiveTab={setActiveTab}
            />
            <div className="flex-grow">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.3 }}
                >
                  {renderContent()}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </motion.div>
      </div>
      {showProductForm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-filter backdrop-blur-sm">
          <CreateProductForm
            onProductCreated={handleProductCreated}
            onClose={() => setShowProductForm(false)}
            productToEdit={selectedProductForEdit}
          />
        </div>
      )}
      <ConfirmModal
        show={showConfirmModal}
        onConfirm={confirmDelete}
        onClose={() => setShowConfirmModal(false)}
      />
    </div>
  );
};

export default ProfilePage;
