import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { FaLink, FaDollarSign, FaUpload, FaImage, FaPlusCircle, FaArrowRight, FaArrowLeft } from 'react-icons/fa';
import { auth, db } from '../../firebase/firebaseConfig';
import { collection, addDoc, serverTimestamp, doc, updateDoc, query, where, getDocs } from 'firebase/firestore';
import { onAuthStateChanged, User } from 'firebase/auth';
import { createClient } from '@supabase/supabase-js';

// Configuração do Supabase
const supabaseUrl = 'https://vojexmxzggzvjtkcsjsk.supabase.co';
const supabaseKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZvamV4bXh6Z2d6dmp0a2NzanNrIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTc5NzgyNTEsImV4cCI6MjA3MzU1NDI1MX0.foYUkFJzGQTFhkMFoIKzpcs35wDJ8VZV0RadajF8Z4E';
const supabase = createClient(supabaseUrl, supabaseKey);

const BUCKET_NAME = 'infoprodutos';

// INTERFACE DE PROPS
interface CreateProductFormProps {
    onProductCreated: () => void;
    onClose: () => void;
    productToEdit?: any;
}

interface InfoproductData {
    authorId: string;
    productName: string;
    description: string;
    niche: string;
    price: number;
    productType: 'curso' | 'livro';
    coverImageUrl: string;
    fileUrls: string[];
    upsellId: string | null;
    downsellId: string | null;
    createdAt: any;
    status: string;
}

const CreateProductForm: React.FC<CreateProductFormProps> = ({ onProductCreated, onClose, productToEdit }) => {
    // --- Estados do Formulário ---
    const [currentStep, setCurrentStep] = useState(1);
    const [productName, setProductName] = useState('');
    const [description, setDescription] = useState('');
    const [niche, setNiche] = useState('');
    const [price, setPrice] = useState(0);
    const [productType, setProductType] = useState<'curso' | 'livro'>('curso');
    const [coverImage, setCoverImage] = useState<File | null>(null);
    const [courseUrl, setCourseUrl] = useState('');
    const [pdfFiles, setPdfFiles] = useState<File[]>([]);
    const [upsellId, setUpsellId] = useState('');
    const [downsellId, setDownsellId] = useState('');

    // --- Novos estados para a lógica de upsell/downsell ---
    const [user, setUser] = useState<User | null>(null);
    const [userProducts, setUserProducts] = useState<any[]>([]);

    // Estados de UI
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [successLink, setSuccessLink] = useState('');

    // EFEITO para monitorar o usuário e buscar seus produtos
    useEffect(() => {
        const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
            setUser(currentUser);
            if (currentUser) {
                try {
                    const productsRef = collection(db, 'products');
                    // Busca apenas os produtos do usuário logado
                    const q = query(productsRef, where('authorId', '==', currentUser.uid));
                    const querySnapshot = await getDocs(q);
                    const productsList = querySnapshot.docs.map(doc => ({
                        id: doc.id,
                        ...doc.data()
                    }));
                    setUserProducts(productsList);
                } catch (err) {
                    console.error("Erro ao buscar produtos do usuário:", err);
                }
            }
        });
        return () => unsubscribe();
    }, []);

    // EFEITO PARA PREENCHER O FORMULÁRIO QUANDO EM MODO DE EDIÇÃO
    useEffect(() => {
        if (productToEdit) {
            setProductName(productToEdit.productName);
            setDescription(productToEdit.description);
            setNiche(productToEdit.niche);
            setPrice(productToEdit.price);
            setProductType(productToEdit.productType);
            setCourseUrl(productToEdit.fileUrls[0] || '');
            setUpsellId(productToEdit.upsellId || '');
            setDownsellId(productToEdit.downsellId || '');
            // Para imagens de capa e PDFs, a lógica é mais complexa, pois envolve o estado de File.
        }
    }, [productToEdit]);

    // --- Funções de Navegação e Lógica ---
    const nextStep = () => {
        // Validação básica do passo atual antes de avançar
        if (currentStep === 1) {
            if (!productName || !description || !niche || price <= 0) {
                setError('Por favor, preencha todos os campos obrigatórios.');
                return;
            }
        } else if (currentStep === 2) {
            if (productType === 'curso' && !courseUrl) {
                setError('Por favor, insira o link do YouTube.');
                return;
            }
            if (productType === 'livro' && pdfFiles.length === 0 && !productToEdit?.fileUrls?.length) {
                setError('Por favor, faça o upload de pelo menos um arquivo PDF.');
                return;
            }
            if (!coverImage && !productToEdit?.coverImageUrl) {
                setError('Por favor, faça o upload de uma imagem de capa.');
                return;
            }
        }
        setError(''); // Limpa o erro se a validação passar
        setCurrentStep(prev => prev + 1);
    };

    const prevStep = () => setCurrentStep(prev => prev - 1);

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>, fileType: 'pdf' | 'image') => {
        if (e.target.files) {
            if (fileType === 'pdf') {
                setPdfFiles([...pdfFiles, ...Array.from(e.target.files)]);
            } else {
                setCoverImage(e.target.files[0]);
            }
        }
    };

    const uploadToSupabase = async (file: File, path: string): Promise<string> => {
        const filePath = `${path}/${auth.currentUser?.uid}/${Date.now()}_${file.name}`;
        const { data, error } = await supabase.storage.from(BUCKET_NAME).upload(filePath, file);

        if (error) {
            throw new Error(`Erro ao fazer upload para o Supabase: ${error.message}`);
        }

        const { data: publicUrlData } = supabase.storage.from(BUCKET_NAME).getPublicUrl(filePath);
        return publicUrlData.publicUrl;
    };

    const handleFinalSubmit = async () => {
        setLoading(true);
        setError('');
        setSuccessLink('');

        try {
            // Revalidação final antes do envio
            if (!productName || !description || !niche || price <= 0) {
                setError('Por favor, preencha todos os campos obrigatórios.');
                return;
            }
            if (productType === 'curso' && !courseUrl) {
                setError('Por favor, insira o link do YouTube.');
                return;
            }
            if (productType === 'livro' && pdfFiles.length === 0 && !productToEdit?.fileUrls?.length) {
                setError('Por favor, faça o upload de pelo menos um arquivo PDF.');
                return;
            }
            if (!coverImage && !productToEdit?.coverImageUrl) {
                setError('Por favor, faça o upload de uma imagem de capa.');
                return;
            }

            let coverImageUrl = productToEdit?.coverImageUrl;
            let fileUrls = productToEdit?.fileUrls;

            if (coverImage) {
                coverImageUrl = await uploadToSupabase(coverImage, 'covers');
            }

            if (productType === 'livro' && pdfFiles.length > 0) {
                fileUrls = await Promise.all(
                    pdfFiles.map(file => uploadToSupabase(file, 'pdfs'))
                );
            } else if (productType === 'curso') {
                fileUrls = [courseUrl];
            }

            const infoproductData: Partial<InfoproductData> = {
                productName,
                description,
                niche,
                price,
                productType,
                coverImageUrl,
                fileUrls,
                upsellId: upsellId || null,
                downsellId: downsellId || null,
                status: 'Ativo',
            };

            if (productToEdit) {
                const productRef = doc(db, 'products', productToEdit.id);
                await updateDoc(productRef, infoproductData);
                setSuccessLink(`${window.location.origin}/product/${productToEdit.id}`);
            } else {
                const newProductRef = await addDoc(collection(db, 'products'), {
                    ...infoproductData,
                    authorId: auth.currentUser?.uid || '',
                    createdAt: serverTimestamp(),
                });
                const shareableLink = `${window.location.origin}/product/${newProductRef.id}`;
                setSuccessLink(shareableLink);
            }
            onProductCreated();
        } catch (err: any) {
            console.error('Erro ao registrar/atualizar infoproduto:', err);
            setError('Falha ao registrar/atualizar infoproduto: ' + err.message);
        } finally {
            setLoading(false);
        }
    };

    // --- Renderização dos Passos ---
    const renderStep = () => {
        switch (currentStep) {
            case 1:
                return (
                    <motion.div initial={{ x: 100, opacity: 0 }} animate={{ x: 0, opacity: 1 }}>
                        <h4 className="text-lg font-bold mb-4 text-gray-800">Passo 1: Informações Básicas</h4>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Tipo de Infoproduto</label>
                                <select
                                    className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500"
                                    value={productType}
                                    onChange={(e) => setProductType(e.target.value as 'curso' | 'livro')}
                                    disabled={!!productToEdit}
                                >
                                    <option value="curso">Curso Online (YouTube)</option>
                                    <option value="livro">E-book (PDF)</option>
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Nome do Infoproduto</label>
                                <input
                                    type="text"
                                    className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500"
                                    value={productName}
                                    onChange={(e) => setProductName(e.target.value)}
                                    required // Adicionado
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Descrição</label>
                                <textarea
                                    className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500"
                                    rows={4}
                                    value={description}
                                    onChange={(e) => setDescription(e.target.value)}
                                    required // Adicionado
                                ></textarea>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Nicho de Mercado</label>
                                <input
                                    type="text"
                                    className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500"
                                    value={niche}
                                    onChange={(e) => setNiche(e.target.value)}
                                    required // Adicionado
                                />
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Preço (MT)</label>
                                <div className="mt-1 flex rounded-md shadow-sm">
                                    <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">
                                        <FaDollarSign />
                                    </span>
                                    <input
                                        type="number"
                                        min="0"
                                        className="flex-1 block w-full p-3 rounded-none rounded-r-md border border-gray-300 focus:ring-green-500 focus:border-green-500"
                                        value={price}
                                        onChange={(e) => setPrice(parseFloat(e.target.value))}
                                        required // Adicionado
                                    />
                                </div>
                            </div>
                        </div>
                        <div className="mt-6 flex justify-end">
                            <motion.button
                                type="button"
                                onClick={nextStep}
                                className="inline-flex items-center px-6 py-3 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                Continuar <FaArrowRight className="ml-2" />
                            </motion.button>
                        </div>
                    </motion.div>
                );
            case 2:
                return (
                    <motion.div initial={{ x: 100, opacity: 0 }} animate={{ x: 0, opacity: 1 }}>
                        <h4 className="text-lg font-bold mb-4 text-gray-800">Passo 2: Conteúdo</h4>
                        <div className="space-y-4">
                            {/* Campo de Upload de Foto de Capa */}
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Foto de Capa</label>
                                <div className="mt-1">
                                    {coverImage && (
                                        <div className="flex items-center gap-2 p-2 bg-gray-50 rounded-md mb-2">
                                            <FaImage className="text-green-600" />
                                            <span className="text-sm text-gray-700 flex-1">{coverImage.name}</span>
                                        </div>
                                    )}
                                    {productToEdit?.coverImageUrl && !coverImage && (
                                        <div className="flex items-center gap-2 p-2 bg-gray-50 rounded-md mb-2">
                                            <FaImage className="text-green-600" />
                                            <span className="text-sm text-gray-700 flex-1">Imagem atual carregada.</span>
                                        </div>
                                    )}
                                    <label className="flex items-center justify-center w-full px-4 py-3 bg-white border border-dashed border-gray-300 rounded-md cursor-pointer text-gray-700 hover:border-green-500 hover:text-green-600 transition-colors">
                                        <FaUpload className="mr-2" /> Adicionar Imagem de Capa
                                        <input
                                            type="file"
                                            className="hidden"
                                            onChange={(e) => handleFileChange(e, 'image')}
                                            accept="image/*"
                                            required={!productToEdit?.coverImageUrl} // Adicionado, obrigatório apenas na criação
                                        />
                                    </label>
                                </div>
                            </div>

                            {/* Renderização condicional para PDF ou URL */}
                            {productType === 'curso' ? (
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Link do YouTube</label>
                                    <div className="mt-1 flex rounded-md shadow-sm">
                                        <span className="inline-flex items-center px-3 rounded-l-md border border-r-0 border-gray-300 bg-gray-50 text-gray-500 text-sm">
                                            <FaLink />
                                        </span>
                                        <input
                                            type="url"
                                            className="flex-1 block w-full p-3 rounded-none rounded-r-md border border-gray-300 focus:ring-green-500 focus:border-green-500"
                                            value={courseUrl}
                                            onChange={(e) => setCourseUrl(e.target.value)}
                                            placeholder="Ex: https://www.youtube.com/playlist?list=..."
                                            required // Adicionado
                                        />
                                    </div>
                                </div>
                            ) : (
                                <div>
                                    <label className="block text-sm font-medium text-gray-700">Upload de Arquivo(s) (PDF)</label>
                                    <div className="mt-1 flex flex-col space-y-2">
                                        {pdfFiles.map((file, index) => (
                                            <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded-md">
                                                <FaUpload className="text-green-600" />
                                                <span className="text-sm text-gray-700 flex-1">{file.name}</span>
                                            </div>
                                        ))}
                                        <label className="flex items-center justify-center w-full px-4 py-3 bg-white border border-dashed border-gray-300 rounded-md cursor-pointer text-gray-700 hover:border-green-500 hover:text-green-600 transition-colors">
                                            <FaUpload className="mr-2" /> Adicionar PDF
                                            <input
                                                type="file"
                                                className="hidden"
                                                onChange={(e) => handleFileChange(e, 'pdf')}
                                                accept=".pdf"
                                                multiple
                                            />
                                        </label>
                                    </div>
                                </div>
                            )}
                        </div>
                        <div className="mt-6 flex justify-between">
                            <motion.button
                                type="button"
                                onClick={prevStep}
                                className="inline-flex items-center px-6 py-3 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                <FaArrowLeft className="mr-2" /> Voltar
                            </motion.button>
                            <motion.button
                                type="button"
                                onClick={nextStep}
                                className="inline-flex items-center px-6 py-3 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                Continuar <FaArrowRight className="ml-2" />
                            </motion.button>
                        </div>
                    </motion.div>
                );
            case 3:
                return (
                    <motion.div initial={{ x: 100, opacity: 0 }} animate={{ x: 0, opacity: 1 }}>
                        <h4 className="text-lg font-bold mb-4 text-gray-800">Passo 3: Funil de Vendas (Opcional)</h4>
                        <div className="space-y-4">
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Produto de Upsell</label>
                                <p className="text-xs text-gray-500 mb-1">Produto a ser oferecido após a compra deste.</p>
                                <select
                                    className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500"
                                    value={upsellId}
                                    onChange={(e) => setUpsellId(e.target.value)}
                                >
                                    <option value="">Nenhum</option>
                                    {userProducts.map(product => (
                                        <option key={product.id} value={product.id}>{product.productName}</option>
                                    ))}
                                </select>
                            </div>
                            <div>
                                <label className="block text-sm font-medium text-gray-700">Produto de Downsell</label>
                                <p className="text-xs text-gray-500 mb-1">Produto a ser oferecido caso o upsell seja recusado.</p>
                                <select
                                    className="mt-1 block w-full p-3 border border-gray-300 rounded-md shadow-sm focus:ring-green-500 focus:border-green-500"
                                    value={downsellId}
                                    onChange={(e) => setDownsellId(e.target.value)}
                                >
                                    <option value="">Nenhum</option>
                                    {userProducts.map(product => (
                                        <option key={product.id} value={product.id}>{product.productName}</option>
                                    ))}
                                </select>
                            </div>
                        </div>
                        <div className="mt-6 flex justify-between">
                            <motion.button
                                type="button"
                                onClick={prevStep}
                                className="inline-flex items-center px-6 py-3 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50"
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                <FaArrowLeft className="mr-2" /> Voltar
                            </motion.button>
                            <motion.button
                                type="button"
                                onClick={handleFinalSubmit}
                                className="inline-flex items-center px-6 py-3 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500"
                                disabled={loading}
                                whileHover={{ scale: 1.05 }}
                                whileTap={{ scale: 0.95 }}
                            >
                                {loading ? 'Aguarde...' : 'Registrar Infoproduto'}
                            </motion.button>
                        </div>
                    </motion.div>
                );
            default:
                return null;
        }
    };

    return (
        <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="p-6 bg-white rounded-xl shadow-lg border border-gray-100 w-full max-w-lg"
        >
            <h3 className="text-2xl font-bold mb-6 text-gray-900">
                {productToEdit ? 'Editar Infoproduto' : 'Registrar Infoproduto'}
            </h3>

            <div className="flex justify-center mb-6">
                <div className="flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${currentStep >= 1 ? 'bg-green-600' : 'bg-gray-400'}`}>1</div>
                    <div className={`w-16 h-1 mx-2 ${currentStep >= 2 ? 'bg-green-600' : 'bg-gray-400'}`}></div>
                </div>
                <div className="flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${currentStep >= 2 ? 'bg-green-600' : 'bg-gray-400'}`}>2</div>
                    <div className={`w-16 h-1 mx-2 ${currentStep >= 3 ? 'bg-green-600' : 'bg-gray-400'}`}></div>
                </div>
                <div className="flex items-center">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center font-bold text-white ${currentStep >= 3 ? 'bg-green-600' : 'bg-gray-400'}`}>3</div>
                </div>
            </div>

            {error && (
                <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <p className="font-bold">Erro</p>
                    <span className="block sm:inline">{error}</span>
                </div>
            )}

            {successLink ? (
                <div className="text-center p-6 bg-green-50 rounded-lg">
                    <p className="text-lg font-semibold text-green-800 mb-4">Sucesso! Seu produto foi {productToEdit ? 'atualizado' : 'registrado'}.</p>
                    <p className="text-gray-600 mb-2">Compartilhe este link com seus compradores:</p>
                    <div className="bg-gray-100 p-3 rounded-md break-all">
                        <code className="text-sm font-mono text-green-600">{successLink}</code>
                    </div>
                    <motion.button
                        className="mt-6 px-6 py-3 rounded-md bg-green-600 text-white font-bold"
                        onClick={onClose}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                    >
                        Fechar
                    </motion.button>
                </div>
            ) : (
                <div className="space-y-6">
                    {renderStep()}
                </div>
            )}
        </motion.div>
    );
};

export default CreateProductForm;