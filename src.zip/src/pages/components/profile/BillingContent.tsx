import React from 'react';
import { HiOutlineCreditCard } from "react-icons/hi";

const BillingContent: React.FC = () => (
  <>
    <h3 className="text-3xl font-bold mb-6 text-gray-900">Métodos de Pagamento</h3>
    <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
      <p className="text-gray-600 mb-4">Você pode adicionar ou gerenciar seus métodos de pagamento para retirar seus ganhos.</p>
      <div className="flex items-center gap-4 bg-gray-50 p-4 rounded-lg border border-gray-200">
        <HiOutlineCreditCard className="text-4xl text-green-600" />
        <div>
          <p className="font-semibold text-gray-800">M-pesa</p>
          <p className="text-sm text-gray-500">Número de telefone: +258 84 xxx xxxx</p>
        </div>
      </div>
    </div>
  </>
);

export default BillingContent;