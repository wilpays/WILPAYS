import React from 'react';
import { HiOutlineUserCircle, HiOutlineChartBar, HiOutlineCreditCard, HiOutlineCog } from "react-icons/hi";
import { FaUserEdit, FaHistory } from "react-icons/fa";
import { BiPackage } from "react-icons/bi";
import TabButton from './TabButton';

interface SidebarProps {
  producerData: any;
  user: any;
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ producerData, user, activeTab, setActiveTab }) => {
  return (
    <nav className="flex-shrink-0 w-full md:w-64">
      <div className="flex flex-col items-center mb-6">
        <div className="w-24 h-24 rounded-full bg-gray-200 mb-4 flex items-center justify-center text-gray-400 text-6xl">
          <HiOutlineUserCircle />
        </div>
        <h2 className="text-xl font-bold">
          {producerData?.nome || "Carregando..."}
        </h2>
        <p className="text-sm text-gray-500">
          {user?.email || "Carregando..."}
        </p>
      </div>
      <ul className="space-y-2">
        <TabButton label="Dashboard" icon={<HiOutlineChartBar />} isActive={activeTab === "dashboard"} onClick={() => setActiveTab("dashboard")} />
        <TabButton label="Meus Infoprodutos" icon={<BiPackage />} isActive={activeTab === "my-products"} onClick={() => setActiveTab("my-products")} />
        <TabButton label="Histórico de Vendas" icon={<FaHistory />} isActive={activeTab === "earnings"} onClick={() => setActiveTab("earnings")} />
        <TabButton label="Informações Pessoais" icon={<FaUserEdit />} isActive={activeTab === "personal-info"} onClick={() => setActiveTab("personal-info")} />
        <TabButton label="Métodos de Pagamento" icon={<HiOutlineCreditCard />} isActive={activeTab === "billing"} onClick={() => setActiveTab("billing")} />
        <TabButton label="Configurações" icon={<HiOutlineCog />} isActive={activeTab === "settings"} onClick={() => setActiveTab("settings")} />
      </ul>
    </nav>
  );
};

export default Sidebar;