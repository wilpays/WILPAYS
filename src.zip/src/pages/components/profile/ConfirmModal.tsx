import React from 'react';
import { motion } from "framer-motion";

interface ConfirmModalProps {
  show: boolean;
  onConfirm: () => void;
  onClose: () => void;
}

const ConfirmModal: React.FC<ConfirmModalProps> = ({ show, onConfirm, onClose }) => {
  if (!show) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 backdrop-filter backdrop-blur-sm">
      <motion.div
        className="bg-white p-8 rounded-lg shadow-xl max-w-sm text-center"
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        exit={{ scale: 0.8, opacity: 0 }}
      >
        <h4 className="text-2xl font-bold mb-4">Confirmar Exclusão</h4>
        <p className="mb-6">Você tem certeza que deseja apagar este produto? Esta ação é irreversível.</p>
        <div className="flex justify-center gap-4">
          <button
            onClick={onClose}
            className="px-6 py-2 rounded-md bg-gray-200 text-gray-700 font-semibold hover:bg-gray-300"
          >
            Cancelar
          </button>
          <button
            onClick={onConfirm}
            className="px-6 py-2 rounded-md bg-red-500 text-white font-semibold hover:bg-red-600"
          >
            Apagar
          </button>
        </div>
      </motion.div>
    </div>
  );
};

export default ConfirmModal;