import React from 'react';
import { motion } from "framer-motion";
import { FaDollarSign } from "react-icons/fa";
import StatCard from './StatCard';

interface DashboardContentProps {
  producerData: any;
}

const DashboardContent: React.FC<DashboardContentProps> = ({ producerData }) => (
  <>
    <h3 className="text-3xl font-bold mb-6 text-gray-900">Visão Geral</h3>
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-8">
      <StatCard title="Total de Vendas" value={`MT ${producerData?.totalSales || 0}`} />
      <StatCard title="Total de Ganhos" value={`MT ${producerData?.totalEarnings || 0}`} />
      <StatCard title="Produtos Vendidos" value={`${producerData?.productsSold || 0}`} />
    </div>
    <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100 flex flex-col md:flex-row justify-between items-center">
      <div>
        <h4 className="text-xl font-bold mb-2">Saldo Disponível</h4>
        <p className="text-4xl font-extrabold text-green-600">MT {producerData?.availableBalance || 0}</p>
      </div>
      <motion.button
        className="mt-4 md:mt-0 px-6 py-3 rounded-md bg-green-600 text-white font-bold transition-colors hover:bg-green-700 flex items-center gap-2"
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
      >
        <FaDollarSign /> Retirar Ganhos
      </motion.button>
    </div>
  </>
);

export default DashboardContent;