import React from 'react';

const SettingsContent: React.FC = () => (
  <>
    <h3 className="text-3xl font-bold mb-6 text-gray-900">Configurações da Conta</h3>
    <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
      <p className="text-gray-600 mb-4">Gerencie as configurações gerais da sua conta aqui.</p>
    </div>
  </>
);

export default SettingsContent;