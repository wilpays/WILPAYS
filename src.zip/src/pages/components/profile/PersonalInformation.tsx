import React, { useState, useEffect } from 'react';
import { motion } from "framer-motion";
import InputField from './InputField';
import { doc, updateDoc } from "firebase/firestore";
import { db } from "../../../firebase/firebaseConfig"
import { toast } from 'react-toastify';

interface PersonalInformationProps {
  producerData: any;
  user: any;
  onDataUpdated: () => void;
}

const PersonalInformation: React.FC<PersonalInformationProps> = ({ producerData, user, onDataUpdated }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [nome, setNome] = useState(producerData?.nome || "");
  const [telefone, setTelefone] = useState(producerData?.telefone || "");
  const [endereco, setEndereco] = useState(producerData?.endereco || "");
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    setNome(producerData?.nome || "");
    setTelefone(producerData?.telefone || "");
    setEndereco(producerData?.endereco || "");
  }, [producerData]);

  const handleSave = async () => {
    if (!user || !user.uid) {
      toast.error("Usuário não autenticado.");
      return;
    }

    setIsSaving(true);
    try {
      const userRef = doc(db, "usuarios", user.uid);
      await updateDoc(userRef, {
        nome: nome,
        telefone: telefone,
        endereco: endereco,
      });
      toast.success("Dados alterados com sucesso!");
      setIsEditing(false);
      onDataUpdated(); // Notifica o componente pai para recarregar os dados
    } catch (error) {
      console.error("Erro ao atualizar os dados:", error);
      toast.error("Erro ao salvar os dados.");
    } finally {
      setIsSaving(false);
    }
  };

  const handleCancel = () => {
    setIsEditing(false);
    // Volta para os dados originais
    setNome(producerData?.nome || "");
    setTelefone(producerData?.telefone || "");
    setEndereco(producerData?.endereco || "");
  };

  return (
    <>
      <h3 className="text-3xl font-bold mb-6 text-gray-900">Informações Pessoais</h3>
      <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100 space-y-6">
        <InputField
          label="Nome Completo"
          type="text"
          value={nome}
          readOnly={!isEditing}
          onChange={(e) => setNome(e.target.value)}
        />
        <InputField
          label="Email"
          type="email"
          value={producerData?.email || ""}
          readOnly={true} // O email é sempre readOnly
        />
        <InputField
          label="Telefone"
          type="text"
          value={telefone}
          readOnly={!isEditing}
          onChange={(e) => setTelefone(e.target.value)}
        />
        <InputField
          label="Endereço"
          type="text"
          value={endereco}
          readOnly={!isEditing}
          onChange={(e) => setEndereco(e.target.value)}
        />

        <div className="flex gap-4">
          {!isEditing ? (
            <motion.button
              onClick={() => setIsEditing(true)}
              className="w-full md:w-auto px-8 py-3 rounded-md bg-green-600 text-white font-bold transition-colors hover:bg-green-700"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Alterar Dados
            </motion.button>
          ) : (
            <>
              <motion.button
                onClick={handleSave}
                disabled={isSaving}
                className={`w-full md:w-auto px-8 py-3 rounded-md text-white font-bold transition-colors ${isSaving ? 'bg-gray-400 cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700'}`}
                whileHover={{ scale: isSaving ? 1 : 1.05 }}
                whileTap={{ scale: isSaving ? 1 : 0.95 }}
              >
                {isSaving ? "Salvando..." : "Salvar"}
              </motion.button>
              <motion.button
                onClick={handleCancel}
                disabled={isSaving}
                className="w-full md:w-auto px-8 py-3 rounded-md bg-gray-300 text-gray-800 font-bold transition-colors hover:bg-gray-400"
                whileHover={{ scale: isSaving ? 1 : 1.05 }}
                whileTap={{ scale: isSaving ? 1 : 0.95 }}
              >
                Cancelar
              </motion.button>
            </>
          )}
        </div>
      </div>
    </>
  );
};

export default PersonalInformation;