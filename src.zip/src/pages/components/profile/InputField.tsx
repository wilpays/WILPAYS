import React from 'react';

// Ajuste na interface para incluir 'onChange' e 'readOnly'
interface InputFieldProps {
  label: string;
  type: string;
  value: any;
  readOnly?: boolean;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
}

const InputField: React.FC<InputFieldProps> = ({ label, type, value, readOnly = false, onChange }) => {
  return (
    <div>
      <label className="block text-sm font-medium text-gray-700">{label}</label>
      <input
        type={type}
        value={value}
        readOnly={readOnly}
        onChange={onChange}
        className={`mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-green-500 focus:ring-green-500 sm:text-sm p-2
          ${readOnly ? 'bg-gray-100 cursor-not-allowed' : 'bg-white'}`}
      />
    </div>
  );
};

export default InputField;