import React from 'react';

interface EarningsHistoryContentProps {
  earningsHistory: any[];
}

const EarningsHistoryContent: React.FC<EarningsHistoryContentProps> = ({ earningsHistory }) => (
  <>
    <h3 className="text-3xl font-bold mb-6 text-gray-900">Histórico de Vendas</h3>
    <div className="bg-white p-6 rounded-lg shadow-md border border-gray-100">
      {earningsHistory.length > 0 ? (
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Infoproduto</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Comprador</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Preço</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Data</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {earningsHistory.map((item) => (
                <tr key={item.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.productName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.buyerName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-bold">MT {item.amount}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{new Date(item.date.seconds * 1000).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <div className="text-center p-6 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
          <p className="font-semibold text-gray-600">Nenhuma venda registrada ainda.</p>
        </div>
      )}
    </div>
  </>
);

export default EarningsHistoryContent;