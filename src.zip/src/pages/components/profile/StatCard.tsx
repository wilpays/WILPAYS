import React from 'react';
import { motion } from "framer-motion";

interface StatCardProps {
  title: string;
  value: string;
}

const StatCard: React.FC<StatCardProps> = ({ title, value }) => (
  <motion.div
    className="bg-green-600 text-white p-6 rounded-lg shadow-md"
    whileHover={{ scale: 1.02 }}
  >
    <p className="text-sm opacity-80">{title}</p>
    <p className="text-3xl font-bold mt-1">{value}</p>
  </motion.div>
);

export default StatCard;