import React, { useState, useMemo, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { HiPencil, HiCheckCircle, HiBan, HiOutlineTrash, HiSearch, HiOutlineDocumentDuplicate, HiOutlineCheck } from "react-icons/hi";
import { FaPlusCircle } from "react-icons/fa";
import { toast } from 'react-toastify';

interface MyProductsContentProps {
  myProducts: any[];
  setShowProductForm: (show: boolean) => void;
  handleEdit: (product: any) => void;
  handleToggleStatus: (id: string, status: string) => void;
  handleDelete: (id: string) => void;
}

const PRODUCTS_PER_PAGE = 5;

const MyProductsContent: React.FC<MyProductsContentProps> = ({ myProducts, setShowProductForm, handleEdit, handleToggleStatus, handleDelete }) => {
  const [searchTerm, setSearchTerm] = useState("");
  const [currentPage, setCurrentPage] = useState(1);
  const [copiedProduct, setCopiedProduct] = useState<string | null>(null);

  // Filtra os produtos com base no termo de busca
  const filteredProducts = useMemo(() => {
    return myProducts.filter(product =>
      product.productName.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [myProducts, searchTerm]);

  // Reseta a página para 1 sempre que o termo de busca mudar
  useEffect(() => {
    setCurrentPage(1);
  }, [searchTerm]);

  // Calcula os produtos para a página atual
  const totalPages = Math.ceil(filteredProducts.length / PRODUCTS_PER_PAGE);
  const currentProducts = useMemo(() => {
    const startIndex = (currentPage - 1) * PRODUCTS_PER_PAGE;
    const endIndex = startIndex + PRODUCTS_PER_PAGE;
    return filteredProducts.slice(startIndex, endIndex);
  }, [filteredProducts, currentPage]);

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleCopyLink = (productId: string) => {
    const productLink = `${window.location.origin}/product/${productId}`; // Ajuste a URL base conforme necessário
    navigator.clipboard.writeText(productLink)
      .then(() => {
        setCopiedProduct(productId);
        toast.success("Link copiado!");
        setTimeout(() => setCopiedProduct(null), 2000); // Reset after 2 seconds
      })
      .catch(err => {
        console.error("Erro ao copiar link:", err);
        toast.error("Erro ao copiar o link.");
      });
  };

  return (
    <>
      <h3 className="text-3xl font-bold mb-6 text-gray-900">Meus Infoprodutos</h3>

      {/* Barra de Pesquisa */}
      <div className="relative mb-6">
        <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
          <HiSearch className="w-5 h-5 text-gray-500" />
        </div>
        <input
          type="text"
          placeholder="Buscar por nome do produto..."
          className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {/* Grid de Produtos */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        <motion.button
          onClick={() => { setShowProductForm(true); handleEdit(null); }}
          className="flex flex-col items-center justify-center p-6 bg-white text-green-600 rounded-lg border-2 border-dashed border-green-600 hover:bg-green-600 hover:text-white transition-colors cursor-pointer"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <FaPlusCircle className="text-4xl mb-2" />
          <p className="font-semibold text-center">Criar Infoproduto</p>
        </motion.button>

        {currentProducts.length > 0 ? (
          currentProducts.map((product) => (
            <motion.div
              key={product.id}
              className="bg-white p-4 rounded-lg shadow-md hover:shadow-lg transition-shadow flex flex-col justify-between h-full"
              whileHover={{ y: -3 }}
            >
              {product.coverImageUrl && (
                <div className="mb-4 rounded-lg overflow-hidden h-40">
                  <img src={product.coverImageUrl} alt={`Capa do produto ${product.productName}`} className="w-full h-full object-cover" />
                </div>
              )}
              <div>
                <h5 className="font-bold text-gray-900">{product.productName}</h5>
                <p className="text-sm text-gray-600 mb-2">
                  <span className={`px-2 py-1 rounded-full text-xs font-semibold ${product.status === "Ativo" ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                    {product.status}
                  </span>
                </p>
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>Preço: MT {product.price}</span>
                </div>
              </div>
              <div className="mt-4 flex gap-2">
                <motion.button onClick={() => handleEdit(product)} className="flex-1 py-2 rounded-md bg-green-500 text-white font-bold transition-colors hover:bg-green-600 flex items-center justify-center gap-2" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <HiPencil /> Editar
                </motion.button>
                <motion.button onClick={() => handleToggleStatus(product.id, product.status)} className="flex-1 py-2 rounded-md transition-colors font-bold flex items-center justify-center gap-2" style={{ backgroundColor: product.status === 'Ativo' ? 'rgb(248 113 113)' : 'rgb(52 211 153)', color: 'white' }} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  {product.status === 'Ativo' ? <HiBan /> : <HiCheckCircle />} {product.status === 'Ativo' ? 'Desativar' : 'Ativar'}
                </motion.button>
                <motion.button onClick={() => handleDelete(product.id)} className="py-2 px-4 rounded-md bg-gray-200 text-gray-700 transition-colors hover:bg-gray-300 flex items-center justify-center" whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
                  <HiOutlineTrash />
                </motion.button>
              </div>
              {/* Novo Botão de Copiar Link */}
              <div className="mt-2">
                <motion.button
                  onClick={() => handleCopyLink(product.id)}
                  className="w-full py-2 rounded-md bg-green-600 text-white font-bold transition-colors hover:bg-green-700 flex items-center justify-center gap-2"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  {copiedProduct === product.id ? <HiOutlineCheck className="text-xl" /> : <HiOutlineDocumentDuplicate className="text-xl" />}
                  {copiedProduct === product.id ? 'Copiado!' : 'Copiar Link'}
                </motion.button>
              </div>
            </motion.div>
          ))
        ) : (
          <div className="col-span-full text-center p-6 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
            <p className="font-semibold text-gray-600">Nenhum infoproduto encontrado.</p>
          </div>
        )}
      </div>

      {/* Controles de Paginação */}
      {filteredProducts.length > 0 && (
        <div className="mt-8 flex justify-center items-center gap-4">
          <button
            onClick={handlePreviousPage}
            disabled={currentPage === 1}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
              currentPage === 1 ? "bg-gray-300 text-gray-500 cursor-not-allowed" : "bg-green-600 text-white hover:bg-green-700"
            }`}
          >
            Anterior
          </button>
          <span className="text-gray-700 font-semibold">
            Página {currentPage} de {totalPages}
          </span>
          <button
            onClick={handleNextPage}
            disabled={currentPage === totalPages}
            className={`px-4 py-2 rounded-lg font-semibold transition-colors ${
              currentPage === totalPages ? "bg-gray-300 text-gray-500 cursor-not-allowed" : "bg-green-600 text-white hover:bg-green-700"
            }`}
          >
            Próxima
          </button>
        </div>
      )}
    </>
  );
};

export default MyProductsContent;