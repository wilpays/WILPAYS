import React from "react";
import { motion } from "framer-motion";

interface TabButtonProps {
  label: string;
  icon: React.ReactNode;
  isActive: boolean;
  onClick: () => void;
}

const TabButton: React.FC<TabButtonProps> = ({ label, icon, isActive, onClick }) => (
  <motion.li
    className={`flex items-center gap-4 px-4 py-3 rounded-lg cursor-pointer transition-all ${
      isActive
        ? "bg-green-100 text-green-700 font-semibold"
        : "hover:bg-gray-50 text-gray-600"
    }`}
    onClick={onClick}
    whileHover={{ scale: 1.02 }}
    whileTap={{ scale: 0.98 }}
  >
    <div className="text-2xl">{icon}</div>
    <span>{label}</span>
  </motion.li>
);

export default TabButton;