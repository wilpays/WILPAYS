import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const slides = [
  {
    title: 'Transforme sua presença online',
    description: 'Soluções de marketing digital que impulsionam seu negócio.',
  },
  {
    title: 'Alcance novos clientes',
    description: 'Estratégias otimizadas para o seu crescimento.',
  },
  {
    title: 'Seja visto. Seja lembrado.',
    description: 'Aumente seu tráfego e conversões com a Wilpays.',
  },
];

const HeroSection: React.FC = () => {
  const [currentSlide, setCurrentSlide] = useState(0);
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentSlide((prevSlide) => (prevSlide + 1) % slides.length);
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  return (
    <header className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden bg-[#121212] font-poppins text-gray-100">
      {/* Animação de Fundo */}
      <div
        className="absolute inset-0 z-0 opacity-10"
        style={{
          backgroundImage: 'radial-gradient(circle, #007bff 1px, transparent 1px)',
          backgroundSize: '20px 20px',
          animation: 'background-pan 30s linear infinite',
        }}
      ></div>
      <style>
        {`
          @keyframes background-pan {
            from { background-position: 0% 0%; }
            to { background-position: 100% 100%; }
          }
        `}
      </style>

      {/* Navbar */}
      <motion.nav
        className="fixed top-0 left-0 right-0 z-20 flex justify-between items-center py-6 px-8 backdrop-blur-md bg-black/40 md:px-12"
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ type: 'spring', stiffness: 120, damping: 14 }}
      >
        <div className="text-2xl font-bold text-white z-50">
          <a href="#">Wilpays</a>
        </div>

        {/* Botão do Menu Hambúrguer (Mobile) */}
        <button className="md:hidden z-50 text-white focus:outline-none" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={isMenuOpen ? 'M6 18L18 6M6 6l12 12' : 'M4 6h16M4 12h16m-7 6h7'} />
          </svg>
        </button>

        {/* Menu e Botões (Desktop) */}
        {/* Usamos flex e 'space-x-8' para espaçamento e 'justify-center' para alinhamento central em telas grandes */}
        <div className="hidden md:flex flex-grow justify-center">
            {/* Menu Principal (Desktop) */}
            <ul className="flex space-x-8">
              <li><a href="#inicio" className="font-semibold hover:text-blue-500 transition-colors">Página inicial</a></li>
              <li><a href="#taxas" className="font-semibold hover:text-blue-500 transition-colors">Taxas</a></li>
              <li><a href="#planos" className="font-semibold hover:text-blue-500 transition-colors">Planos</a></li>
              <li><a href="#servicos" className="font-semibold hover:text-blue-500 transition-colors">Serviços</a></li>
            </ul>
        </div>
        <div className="hidden md:flex space-x-4">
            <motion.button
              className="px-6 py-2 rounded-md border-2 border-blue-500 text-blue-500 font-semibold hover:bg-blue-500 hover:text-white transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Login
            </motion.button>
            <motion.button
              className="px-6 py-2 rounded-md bg-blue-500 text-white font-semibold hover:bg-blue-600 transition-colors"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Criar Conta
            </motion.button>
        </div>

        {/* Menu Dropdown (Mobile) */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              className="md:hidden fixed inset-0 z-40 bg-black/80 backdrop-blur-md flex flex-col items-center justify-center space-y-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
            >
              <ul className="flex flex-col items-center space-y-6 text-xl">
                <li><a href="#inicio" onClick={() => setIsMenuOpen(false)} className="font-semibold text-white hover:text-blue-500 transition-colors">Página inicial</a></li>
                <li><a href="#taxas" onClick={() => setIsMenuOpen(false)} className="font-semibold text-white hover:text-blue-500 transition-colors">Taxas</a></li>
                <li><a href="#planos" onClick={() => setIsMenuOpen(false)} className="font-semibold text-white hover:text-blue-500 transition-colors">Planos</a></li>
                <li><a href="#servicos" onClick={() => setIsMenuOpen(false)} className="font-semibold text-white hover:text-blue-500 transition-colors">Serviços</a></li>
              </ul>
              <div className="flex flex-col space-y-4 pt-4">
                <button className="px-8 py-3 rounded-md border-2 border-blue-500 text-blue-500 font-semibold">Login</button>
                <button className="px-8 py-3 rounded-md bg-blue-500 text-white font-semibold">Criar Conta</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.nav>

      {/* Conteúdo Principal Hero */}
      <div className="relative z-10 text-center px-4">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentSlide}
            className="flex flex-col items-center min-h-[150px]"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            transition={{ duration: 0.8 }}
          >
            <motion.h1
              className="text-4xl sm:text-5xl md:text-6xl font-bold leading-tight bg-clip-text text-transparent bg-gradient-to-r from-white to-blue-500"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.2 }}
            >
              {slides[currentSlide].title}
            </motion.h1>
            <motion.p
              className="mt-4 text-lg sm:text-xl md:text-2xl opacity-80 max-w-2xl"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4 }}
            >
              {slides[currentSlide].description}
            </motion.p>
          </motion.div>
        </AnimatePresence>

        <motion.button
          className="mt-8 px-8 py-3 md:px-12 md:py-4 rounded-full bg-green-500 text-white text-lg md:text-xl font-bold shadow-lg hover:bg-green-600 transition-all"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.5, duration: 0.6 }}
          whileHover={{ scale: 1.05, boxShadow: '0 6px 20px rgba(40, 167, 69, 0.6)' }}
          whileTap={{ scale: 0.95 }}
        >
          Começar agora
        </motion.button>
      </div>
    </header>
  );
};

export default HeroSection;