import { useState } from "react";
import { useNavigate } from "react-router-dom";
import emailjs from "emailjs-com";

const Signup = () => {
  const [formData, setFormData] = useState({
    nome: "",
    email: "",
    genero: "",
    idade: "",
    telefone: "",
    endereco: "",
    tipoUsuario: "",
    senha: "",
  });

  const navigate = useNavigate();

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.email || !formData.nome) {
      alert("Por favor, preencha seu nome e e-mail corretamente.");
      return;
    }

    const codigo = Math.floor(100000 + Math.random() * 900000).toString();
    localStorage.setItem("signupData", JSON.stringify(formData));
    localStorage.setItem("codigoVerificacao", codigo);

    const templateParams = {
      to_name: formData.nome,
      to_email: formData.email,
      passcode: codigo,
      time: new Date(Date.now() + 15 * 60000).toLocaleTimeString(),
    };

    try {
      await emailjs.send(
        "service_ewdde7s",
        "template_rzit9yp",
        templateParams,
        "2ZUsFb4KFDe4CGIM4"
      );
      navigate("/confirmar-codigo");
    } catch (error) {
      console.error("Erro ao enviar email:", error);
      alert("Erro ao enviar o código. Verifique os dados do EmailJS.");
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4 py-12">
      <div className="w-full max-w-5xl bg-white shadow-xl rounded-2xl p-10">
        <div className="flex justify-between items-center mb-8">
          <h2 className="text-3xl font-semibold text-gray-800">Criar Conta</h2>
          <button
            onClick={() => navigate("/login")}
            className="text-sm text-blue-600 hover:underline"
          >
            Já tens uma conta?{" "}
            <span className="font-medium">Iniciar sessão</span>
          </button>
        </div>

        <form
          onSubmit={handleSubmit}
          className="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6"
        >
          {[
            { name: "nome", label: "Nome completo", type: "text" },
            { name: "email", label: "Email", type: "email" },
            { name: "idade", label: "Idade", type: "number" },
            { name: "telefone", label: "Telefone", type: "tel" },
            { name: "endereco", label: "Endereço", type: "text" },
            {
              name: "genero",
              label: "Gênero",
              type: "select",
              options: ["Masculino", "Feminino", "Outro"],
            },
            {
              name: "tipoUsuario",
              label: "Tipo de usuário",
              type: "select",
              options: ["Cliente", "Afiliado"],
            },
            { name: "senha", label: "Senha", type: "password" },
          ].map(({ name, label, type }) => (
            <div key={name} className="relative">
              <input
                name={name}
                type={type}
                value={formData[name as keyof typeof formData]}
                onChange={handleChange}
                required
                className="peer w-full border border-gray-300 rounded-md px-3 pt-5 pb-2 text-sm placeholder-transparent focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder={label}
              />
              <label
                htmlFor={name}
                className="absolute left-3 top-2 text-gray-500 text-xs transition-all peer-placeholder-shown:top-3.5 peer-placeholder-shown:text-sm peer-placeholder-shown:text-gray-400 peer-focus:top-2 peer-focus:text-xs peer-focus:text-blue-500"
              >
                {label}
              </label>
            </div>
          ))}

          <div className="relative">
            <select
              name="genero"
              value={formData.genero}
              onChange={handleChange}
              required
              className="peer w-full border border-gray-300 rounded-md px-3 pt-5 pb-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="" disabled hidden>
                Gênero
              </option>
              <option value="masculino">Masculino</option>
              <option value="feminino">Feminino</option>
              <option value="outro">Outro</option>
            </select>
            <label
              htmlFor="genero"
              className="absolute left-3 top-2 text-gray-500 text-xs transition-all peer-focus:text-blue-500"
            >
              Gênero
            </label>
          </div>

          <div className="relative">
            <select
              name="tipoUsuario"
              value={formData.tipoUsuario}
              onChange={handleChange}
              required
              className="peer w-full border border-gray-300 rounded-md px-3 pt-5 pb-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="" disabled hidden>
                Tipo de usuário
              </option>
              <option value="cliente">Cliente</option>
              <option value="afiliado">Afiliado</option>
            </select>
            <label
              htmlFor="tipoUsuario"
              className="absolute left-3 top-2 text-gray-500 text-xs transition-all peer-focus:text-blue-500"
            >
              Tipo de usuário
            </label>
          </div>

          <div className="md:col-span-2 mt-6">
            <button
              type="submit"
              className="w-full py-3 bg-blue-600 text-white font-medium rounded-md hover:bg-blue-700 transition"
            >
              Enviar código de confirmação
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Signup;
