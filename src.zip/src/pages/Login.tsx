import { useState } from "react";
import { auth } from "../firebase/firebaseConfig";
import { db } from "../firebase/firebaseConfig";
import { doc, getDoc } from "firebase/firestore";

import {
  signInWithEmailAndPassword,
  GoogleAuthProvider,
  signInWithPopup,
} from "firebase/auth";
import { useNavigate, Link } from "react-router-dom";
import { FcGoogle } from "react-icons/fc";
import loginImage from "../assets/background.jpg"; // ajuste o caminho conforme necessário

export default function Login() {
  const [email, setEmail] = useState("");
  const [senha, setSenha] = useState("");
  const [erro, setErro] = useState("");
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setErro("");
    try {
      await signInWithEmailAndPassword(auth, email, senha);
      navigate("/");
    } catch (err: any) {
      setErro("Email ou senha inválidos.");
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    setLoading(true);
    setErro("");
    const provider = new GoogleAuthProvider();

    try {
      const result = await signInWithPopup(auth, provider);
      const user = result.user;

      // Verifica se o usuário existe no Firestore
      const userDocRef = doc(db, "usuarios", user.uid);
      const userDoc = await getDoc(userDocRef);

      if (!userDoc.exists()) {
        // Desloga imediatamente
        await auth.signOut();

        // Opcional: remove o usuário do Auth
        try {
          await user.delete();
        } catch (deleteError) {
          console.warn(
            "Não foi possível deletar o usuário do Auth:",
            deleteError
          );
        }

        setErro(
          "Conta Google não registrada. Por favor, cadastre-se primeiro."
        );
        return;
      }

      // Usuário existe, segue para home
      navigate("/");
    } catch (err: any) {
      setErro("Falha ao autenticar com Google.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-white flex items-center justify-center px-4">
      <div className="flex flex-col md:flex-row bg-gray-100 rounded-xl shadow-lg overflow-hidden max-w-4xl w-full">
        {/* Imagem lateral */}
        <div className="md:w-1/2 hidden md:block">
          <img
            src={loginImage}
            alt="Login visual"
            className="h-full w-full object-cover"
          />
        </div>

        {/* Formulário */}
        <div className="md:w-1/2 p-8">
          <h2 className="text-3xl font-bold text-indigo-700 mb-6 text-center">
            Entrar no Willpays
          </h2>
          {erro && (
            <p className="text-red-500 text-sm mb-4 text-center">{erro}</p>
          )}
          <form onSubmit={handleLogin} className="space-y-4">
            <input
              type="email"
              placeholder="Email"
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <input
              type="password"
              placeholder="Senha"
              className="w-full px-4 py-2 border rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500"
              value={senha}
              onChange={(e) => setSenha(e.target.value)}
              required
            />
            <button
              type="submit"
              disabled={loading}
              className={`w-full py-2 rounded-md transition ${
                loading
                  ? "bg-indigo-300 cursor-not-allowed"
                  : "bg-indigo-600 hover:bg-indigo-700 text-white"
              }`}
            >
              {loading ? "Entrando..." : "Entrar"}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-gray-600 mb-2">ou</p>
            <button
              onClick={handleGoogleLogin}
              disabled={loading}
              className="w-full flex items-center justify-center gap-2 bg-white border py-2 rounded-md hover:bg-gray-100 transition"
            >
              <FcGoogle size={24} />
              <span className="text-gray-700 font-medium">
                Entrar com Google
              </span>
            </button>
          </div>

          <div className="mt-6 text-center">
            <p className="text-sm text-gray-600">
              Não tem conta?{" "}
              <Link
                to="/signup"
                className="text-indigo-600 hover:underline font-medium"
              >
                Registre-se
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
